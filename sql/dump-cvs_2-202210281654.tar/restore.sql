--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.12 (Ubuntu 12.12-0ubuntu0.20.04.1)
-- Dumped by pg_dump version 12.12 (Ubuntu 12.12-0ubuntu0.20.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE cvs_2;
--
-- Name: cvs_2; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE cvs_2 WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'es_PY.UTF-8' LC_CTYPE = 'es_PY.UTF-8';


ALTER DATABASE cvs_2 OWNER TO postgres;

\connect cvs_2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: calcular_total_presupuesto(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.calcular_total_presupuesto() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
		UPDATE presupuestos SET presu_total = (presu_total + (NEW.cant_presu * NEW.precio_presu)) WHERE presupuestos.presu_id = NEW.presu_id;
		RETURN new;
	END;
$$;


ALTER FUNCTION public.calcular_total_presupuesto() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ajuste; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ajuste (
    id integer NOT NULL,
    cantidad integer,
    descripcion character varying(255),
    estado character varying(255),
    fecha timestamp without time zone,
    tipo character varying(255),
    id_stock integer,
    id_estado integer
);


ALTER TABLE public.ajuste OWNER TO postgres;

--
-- Name: ajuste_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ajuste_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ajuste_id_seq OWNER TO postgres;

--
-- Name: ajuste_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ajuste_id_seq OWNED BY public.ajuste.id;


--
-- Name: apertura_cierre_caja; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.apertura_cierre_caja (
    id integer NOT NULL,
    descripcion character varying(255),
    estado character varying(255),
    fecha_hora_apertura timestamp without time zone,
    fecha_hora_cierre timestamp without time zone,
    monto_apertura bigint,
    monto_cierre bigint,
    monto_cierre_cheque bigint,
    monto_cierre_efectivo bigint,
    monto_cierre_tarjeta bigint,
    id_caja integer,
    id_usuario integer
);


ALTER TABLE public.apertura_cierre_caja OWNER TO postgres;

--
-- Name: apertura_cierre_caja_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.apertura_cierre_caja_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.apertura_cierre_caja_id_seq OWNER TO postgres;

--
-- Name: apertura_cierre_caja_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.apertura_cierre_caja_id_seq OWNED BY public.apertura_cierre_caja.id;


--
-- Name: articulo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.articulo (
    id integer NOT NULL,
    descripcion character varying NOT NULL,
    precio_compra bigint NOT NULL,
    precio_venta bigint NOT NULL,
    codigo_generico character varying NOT NULL,
    id_impuesto integer NOT NULL,
    id_marca integer NOT NULL,
    id_tipo_articulo integer NOT NULL,
    estado character varying,
    precio_compra_anterior bigint,
    precio_venta_anterior bigint
);


ALTER TABLE public.articulo OWNER TO postgres;

--
-- Name: articulo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.articulo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.articulo_id_seq OWNER TO postgres;

--
-- Name: articulo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.articulo_id_seq OWNED BY public.articulo.id;


--
-- Name: banco; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.banco (
    id integer NOT NULL,
    descripcion character varying(200) NOT NULL,
    estado character varying
);


ALTER TABLE public.banco OWNER TO postgres;

--
-- Name: banco_banco_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.banco_banco_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.banco_banco_id_seq OWNER TO postgres;

--
-- Name: banco_banco_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.banco_banco_id_seq OWNED BY public.banco.id;


--
-- Name: banco_cheque; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.banco_cheque (
    id integer NOT NULL,
    descripcion character varying,
    estado character varying
);


ALTER TABLE public.banco_cheque OWNER TO postgres;

--
-- Name: banco_cheque_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.banco_cheque_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.banco_cheque_id_seq OWNER TO postgres;

--
-- Name: banco_cheque_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.banco_cheque_id_seq OWNED BY public.banco_cheque.id;


--
-- Name: caja; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.caja (
    id integer NOT NULL,
    descripcion character varying(90) NOT NULL,
    numero integer NOT NULL,
    estado character varying,
    id_sucursal integer
);


ALTER TABLE public.caja OWNER TO postgres;

--
-- Name: caja_caja_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.caja_caja_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.caja_caja_id_seq OWNER TO postgres;

--
-- Name: caja_caja_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.caja_caja_id_seq OWNED BY public.caja.id;


--
-- Name: cargo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cargo (
    id integer NOT NULL,
    descripcion character varying,
    estado character varying
);


ALTER TABLE public.cargo OWNER TO postgres;

--
-- Name: cargo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cargo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cargo_id_seq OWNER TO postgres;

--
-- Name: cargo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cargo_id_seq OWNED BY public.cargo.id;


--
-- Name: ciudad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ciudad (
    id integer NOT NULL,
    descripcion character varying,
    estado character varying
);


ALTER TABLE public.ciudad OWNER TO postgres;

--
-- Name: ciudad_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ciudad_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ciudad_id_seq OWNER TO postgres;

--
-- Name: ciudad_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ciudad_id_seq OWNED BY public.ciudad.id;


--
-- Name: cliente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cliente (
    id integer NOT NULL,
    correo character varying(255),
    direccion character varying(255),
    estado character varying(255),
    razon character varying(255),
    ruc character varying(255),
    telefono character varying(255),
    id_ciudad integer
);


ALTER TABLE public.cliente OWNER TO postgres;

--
-- Name: cliente_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cliente_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cliente_id_seq OWNER TO postgres;

--
-- Name: cliente_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cliente_id_seq OWNED BY public.cliente.id;


--
-- Name: cobro; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cobro (
    id integer NOT NULL,
    descripcion character varying(255),
    estado character varying(255),
    fecha timestamp without time zone,
    monto bigint
);


ALTER TABLE public.cobro OWNER TO postgres;

--
-- Name: cobro_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cobro_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cobro_id_seq OWNER TO postgres;

--
-- Name: cobro_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cobro_id_seq OWNED BY public.cobro.id;


--
-- Name: condicion_pago; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.condicion_pago (
    id integer NOT NULL,
    descripcion character varying,
    estado character varying
);


ALTER TABLE public.condicion_pago OWNER TO postgres;

--
-- Name: condicion_pago_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.condicion_pago_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.condicion_pago_id_seq OWNER TO postgres;

--
-- Name: condicion_pago_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.condicion_pago_id_seq OWNED BY public.condicion_pago.id;


--
-- Name: cuenta_a_cobrar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cuenta_a_cobrar (
    id integer NOT NULL,
    cantidad_cuotas integer,
    estado character varying(255),
    fecha_vencimiento timestamp without time zone,
    monto bigint,
    numero_cuota integer,
    id_cobro integer,
    id_estado integer,
    id_factura integer
);


ALTER TABLE public.cuenta_a_cobrar OWNER TO postgres;

--
-- Name: cuenta_a_cobrar_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cuenta_a_cobrar_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cuenta_a_cobrar_id_seq OWNER TO postgres;

--
-- Name: cuenta_a_cobrar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cuenta_a_cobrar_id_seq OWNED BY public.cuenta_a_cobrar.id;


--
-- Name: cuenta_a_pagar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cuenta_a_pagar (
    id integer NOT NULL,
    cantidad_cuotas integer,
    estado character varying(255),
    fecha_vencimiento timestamp without time zone,
    monto bigint,
    numero_cuota integer,
    id_estado integer,
    id_pago integer
);


ALTER TABLE public.cuenta_a_pagar OWNER TO postgres;

--
-- Name: cuenta_a_pagar_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cuenta_a_pagar_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cuenta_a_pagar_id_seq OWNER TO postgres;

--
-- Name: cuenta_a_pagar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cuenta_a_pagar_id_seq OWNED BY public.cuenta_a_pagar.id;


--
-- Name: deposito_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.deposito_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.deposito_id_seq OWNER TO postgres;

--
-- Name: deposito; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deposito (
    id integer DEFAULT nextval('public.deposito_id_seq'::regclass) NOT NULL,
    descripcion character varying,
    id_sucursal integer,
    estado character varying
);


ALTER TABLE public.deposito OWNER TO postgres;

--
-- Name: pedido_compra_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pedido_compra_detalle (
    id integer NOT NULL,
    cantidad integer,
    estado character varying(255),
    id_articulo integer,
    id_pedido_compra integer
);


ALTER TABLE public.pedido_compra_detalle OWNER TO postgres;

--
-- Name: detalle_pedido_compra_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.detalle_pedido_compra_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.detalle_pedido_compra_id_seq OWNER TO postgres;

--
-- Name: detalle_pedido_compra_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.detalle_pedido_compra_id_seq OWNED BY public.pedido_compra_detalle.id;


--
-- Name: diagnostico; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.diagnostico (
    id integer NOT NULL,
    estado character varying(255),
    fecha timestamp without time zone,
    observacion character varying(255),
    id_estado integer,
    id_recepcion integer,
    id_usuario integer
);


ALTER TABLE public.diagnostico OWNER TO postgres;

--
-- Name: diagnostico_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.diagnostico_detalle (
    id integer NOT NULL,
    diagnostico character varying(255),
    estado character varying(255),
    id_recepcion_detalle integer,
    id_diagnostico integer,
    id_servicio integer
);


ALTER TABLE public.diagnostico_detalle OWNER TO postgres;

--
-- Name: diagnostico_detalle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.diagnostico_detalle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.diagnostico_detalle_id_seq OWNER TO postgres;

--
-- Name: diagnostico_detalle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.diagnostico_detalle_id_seq OWNED BY public.diagnostico_detalle.id;


--
-- Name: diagnostico_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.diagnostico_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.diagnostico_id_seq OWNER TO postgres;

--
-- Name: diagnostico_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.diagnostico_id_seq OWNED BY public.diagnostico.id;


--
-- Name: persona; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.persona (
    id integer NOT NULL,
    nombre character varying NOT NULL,
    apellido character varying NOT NULL,
    ci character varying NOT NULL,
    telefono character varying NOT NULL,
    direccion character varying NOT NULL,
    id_ciudad integer NOT NULL,
    estado character varying
);


ALTER TABLE public.persona OWNER TO postgres;

--
-- Name: empleado_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.empleado_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.empleado_id_seq OWNER TO postgres;

--
-- Name: empleado_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.empleado_id_seq OWNED BY public.persona.id;


--
-- Name: empresa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.empresa (
    id integer NOT NULL,
    telefono character varying(80) NOT NULL,
    direccion character varying(150) NOT NULL,
    nombre character varying(70) NOT NULL,
    ruc character varying(20) NOT NULL,
    estado character varying
);


ALTER TABLE public.empresa OWNER TO postgres;

--
-- Name: empresa_empre_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.empresa_empre_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.empresa_empre_id_seq OWNER TO postgres;

--
-- Name: empresa_empre_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.empresa_empre_id_seq OWNED BY public.empresa.id;


--
-- Name: encargado; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.encargado (
    id integer NOT NULL,
    id_sucursal integer NOT NULL,
    nombre character varying(60) NOT NULL,
    apellido character varying(60) NOT NULL,
    direccion character varying(60) NOT NULL,
    telefono character varying(60) NOT NULL,
    email character varying(60) NOT NULL
);


ALTER TABLE public.encargado OWNER TO postgres;

--
-- Name: encargado_enca_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.encargado_enca_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.encargado_enca_id_seq OWNER TO postgres;

--
-- Name: encargado_enca_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.encargado_enca_id_seq OWNED BY public.encargado.id;


--
-- Name: entidad_emisora; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.entidad_emisora (
    id integer NOT NULL,
    descripcion character varying,
    estado character varying
);


ALTER TABLE public.entidad_emisora OWNER TO postgres;

--
-- Name: entidad_emisora_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.entidad_emisora_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.entidad_emisora_id_seq OWNER TO postgres;

--
-- Name: entidad_emisora_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.entidad_emisora_id_seq OWNED BY public.entidad_emisora.id;


--
-- Name: equipo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.equipo (
    id integer NOT NULL,
    serie character varying NOT NULL,
    descripcion character varying NOT NULL,
    modelo character varying(60) NOT NULL,
    id_marca integer NOT NULL,
    estado character varying,
    id_cliente integer
);


ALTER TABLE public.equipo OWNER TO postgres;

--
-- Name: equipos_equi_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.equipos_equi_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.equipos_equi_id_seq OWNER TO postgres;

--
-- Name: equipos_equi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.equipos_equi_id_seq OWNED BY public.equipo.id;


--
-- Name: estado; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estado (
    id integer NOT NULL,
    descripcion character varying,
    estado character varying
);


ALTER TABLE public.estado OWNER TO postgres;

--
-- Name: estado_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.estado_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.estado_id_seq OWNER TO postgres;

--
-- Name: estado_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.estado_id_seq OWNED BY public.estado.id;


--
-- Name: factura; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.factura (
    id integer NOT NULL,
    estado character varying(255),
    fecha timestamp without time zone,
    monto bigint,
    numerofactura character varying(255),
    observacion character varying(255),
    id_caja integer,
    id_condicion_pago integer,
    id_estado integer,
    id_libro_venta integer,
    id_pedido_venta integer,
    id_timbrado integer,
    id_usuario integer
);


ALTER TABLE public.factura OWNER TO postgres;

--
-- Name: factura_compra; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.factura_compra (
    id integer NOT NULL,
    estado character varying(255),
    fecha timestamp without time zone,
    monto bigint,
    numero_factura character varying(255),
    observacion character varying(255),
    id_estado integer,
    id_libro_compra integer,
    id_orden_compra integer,
    id_usuario integer
);


ALTER TABLE public.factura_compra OWNER TO postgres;

--
-- Name: factura_compra_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.factura_compra_detalle (
    id integer NOT NULL,
    estado character varying(255),
    id_orden_compra_detalle integer,
    id_factura_compra integer
);


ALTER TABLE public.factura_compra_detalle OWNER TO postgres;

--
-- Name: factura_compra_detalle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.factura_compra_detalle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.factura_compra_detalle_id_seq OWNER TO postgres;

--
-- Name: factura_compra_detalle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.factura_compra_detalle_id_seq OWNED BY public.factura_compra_detalle.id;


--
-- Name: factura_compra_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.factura_compra_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.factura_compra_id_seq OWNER TO postgres;

--
-- Name: factura_compra_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.factura_compra_id_seq OWNED BY public.factura_compra.id;


--
-- Name: factura_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.factura_detalle (
    id integer NOT NULL,
    estado character varying(255),
    monto bigint,
    id_oreden_servicio_detalle integer,
    id_pedido_venta_detalle integer,
    id_factura integer
);


ALTER TABLE public.factura_detalle OWNER TO postgres;

--
-- Name: factura_detalle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.factura_detalle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.factura_detalle_id_seq OWNER TO postgres;

--
-- Name: factura_detalle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.factura_detalle_id_seq OWNED BY public.factura_detalle.id;


--
-- Name: factura_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.factura_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.factura_id_seq OWNER TO postgres;

--
-- Name: factura_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.factura_id_seq OWNED BY public.factura.id;


--
-- Name: forma_cobro; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.forma_cobro (
    id integer NOT NULL,
    descripcion character varying(40) NOT NULL,
    estado character varying
);


ALTER TABLE public.forma_cobro OWNER TO postgres;

--
-- Name: forma_cobro_form_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.forma_cobro_form_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.forma_cobro_form_id_seq OWNER TO postgres;

--
-- Name: forma_cobro_form_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.forma_cobro_form_id_seq OWNED BY public.forma_cobro.id;


--
-- Name: formulario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.formulario (
    id integer NOT NULL,
    nombre character varying,
    url character varying,
    id_sistema integer,
    id_sub_menu integer,
    id_usuario_auditoria integer,
    estado character varying
);


ALTER TABLE public.formulario OWNER TO postgres;

--
-- Name: formularios_id_formulario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.formularios_id_formulario_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.formularios_id_formulario_seq OWNER TO postgres;

--
-- Name: formularios_id_formulario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.formularios_id_formulario_seq OWNED BY public.formulario.id;


--
-- Name: impuesto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.impuesto (
    id integer NOT NULL,
    descripcion character varying,
    estado character varying,
    porcentaje_impuesto integer
);


ALTER TABLE public.impuesto OWNER TO postgres;

--
-- Name: impuesto_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.impuesto_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.impuesto_id_seq OWNER TO postgres;

--
-- Name: impuesto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.impuesto_id_seq OWNED BY public.impuesto.id;


--
-- Name: item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item (
    id integer NOT NULL,
    descripcion character varying(200) NOT NULL,
    precio integer NOT NULL,
    stock integer NOT NULL,
    id_marca integer NOT NULL,
    estado character varying
);


ALTER TABLE public.item OWNER TO postgres;

--
-- Name: items_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.items_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.items_item_id_seq OWNER TO postgres;

--
-- Name: items_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.items_item_id_seq OWNED BY public.item.id;


--
-- Name: libro_compra; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.libro_compra (
    id integer NOT NULL,
    estado character varying(255),
    fecha timestamp without time zone,
    monto_iva_10 bigint,
    monto_iva_5 bigint,
    montoneto bigint
);


ALTER TABLE public.libro_compra OWNER TO postgres;

--
-- Name: libro_compra_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.libro_compra_detalle (
    id integer NOT NULL,
    estado character varying(255),
    monto_impuesto bigint,
    monto_neto bigint,
    id_factura_compra_detalle integer,
    id_impuesto integer,
    id_libro_compra integer
);


ALTER TABLE public.libro_compra_detalle OWNER TO postgres;

--
-- Name: libro_compra_detalle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.libro_compra_detalle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.libro_compra_detalle_id_seq OWNER TO postgres;

--
-- Name: libro_compra_detalle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.libro_compra_detalle_id_seq OWNED BY public.libro_compra_detalle.id;


--
-- Name: libro_compra_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.libro_compra_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.libro_compra_id_seq OWNER TO postgres;

--
-- Name: libro_compra_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.libro_compra_id_seq OWNED BY public.libro_compra.id;


--
-- Name: libro_venta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.libro_venta (
    id integer NOT NULL,
    estado character varying(255),
    fecha timestamp without time zone,
    monto_iva_10 bigint,
    monto_iva_5 bigint,
    montoneto bigint
);


ALTER TABLE public.libro_venta OWNER TO postgres;

--
-- Name: libro_venta_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.libro_venta_detalle (
    id integer NOT NULL,
    estado character varying(255),
    monto_impuesto bigint,
    monto_neto bigint,
    id_factura_detalle integer,
    id_impuesto integer,
    id_libro_venta integer
);


ALTER TABLE public.libro_venta_detalle OWNER TO postgres;

--
-- Name: libro_venta_detalle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.libro_venta_detalle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.libro_venta_detalle_id_seq OWNER TO postgres;

--
-- Name: libro_venta_detalle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.libro_venta_detalle_id_seq OWNED BY public.libro_venta_detalle.id;


--
-- Name: libro_venta_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.libro_venta_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.libro_venta_id_seq OWNER TO postgres;

--
-- Name: libro_venta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.libro_venta_id_seq OWNED BY public.libro_venta.id;


--
-- Name: marca; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marca (
    id integer NOT NULL,
    descripcion character varying(60) NOT NULL,
    estado character varying
);


ALTER TABLE public.marca OWNER TO postgres;

--
-- Name: marcas_mar_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.marcas_mar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.marcas_mar_id_seq OWNER TO postgres;

--
-- Name: marcas_mar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.marcas_mar_id_seq OWNED BY public.marca.id;


--
-- Name: motivo_ajuste; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.motivo_ajuste (
    id integer NOT NULL,
    descripcion character varying(100) NOT NULL,
    estado character varying
);


ALTER TABLE public.motivo_ajuste OWNER TO postgres;

--
-- Name: motivo_ajuste_maju_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.motivo_ajuste_maju_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.motivo_ajuste_maju_id_seq OWNER TO postgres;

--
-- Name: motivo_ajuste_maju_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.motivo_ajuste_maju_id_seq OWNED BY public.motivo_ajuste.id;


--
-- Name: nota_credito_compra; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nota_credito_compra (
    id integer NOT NULL,
    estado character varying(255),
    fecha timestamp without time zone,
    monto bigint,
    observacion character varying(255),
    id_estado integer,
    id_factura_compra integer,
    id_proveedor integer,
    id_orden_compra_cancelacion integer,
    id_usuario integer
);


ALTER TABLE public.nota_credito_compra OWNER TO postgres;

--
-- Name: nota_credito_compra_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nota_credito_compra_detalle (
    id integer NOT NULL,
    cantidad integer,
    estado character varying(255),
    monto bigint,
    id_articulo integer,
    id_nota_credito_compra integer
);


ALTER TABLE public.nota_credito_compra_detalle OWNER TO postgres;

--
-- Name: nota_credito_compra_detalle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.nota_credito_compra_detalle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.nota_credito_compra_detalle_id_seq OWNER TO postgres;

--
-- Name: nota_credito_compra_detalle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.nota_credito_compra_detalle_id_seq OWNED BY public.nota_credito_compra_detalle.id;


--
-- Name: nota_credito_compra_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.nota_credito_compra_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.nota_credito_compra_id_seq OWNER TO postgres;

--
-- Name: nota_credito_compra_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.nota_credito_compra_id_seq OWNED BY public.nota_credito_compra.id;


--
-- Name: nota_debito_compra; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nota_debito_compra (
    id integer NOT NULL,
    estado character varying(255),
    monto bigint,
    numero character varying(255),
    observacion character varying(255),
    id_cuenta_a_pagar integer,
    id_estado integer,
    id_factura_compra integer
);


ALTER TABLE public.nota_debito_compra OWNER TO postgres;

--
-- Name: nota_debito_compra_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nota_debito_compra_detalle (
    id integer NOT NULL,
    estado character varying(255),
    id_factura_compra_detalle integer,
    id_nota_debito integer
);


ALTER TABLE public.nota_debito_compra_detalle OWNER TO postgres;

--
-- Name: nota_debito_compra_detalle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.nota_debito_compra_detalle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.nota_debito_compra_detalle_id_seq OWNER TO postgres;

--
-- Name: nota_debito_compra_detalle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.nota_debito_compra_detalle_id_seq OWNED BY public.nota_debito_compra_detalle.id;


--
-- Name: nota_debito_compra_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.nota_debito_compra_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.nota_debito_compra_id_seq OWNER TO postgres;

--
-- Name: nota_debito_compra_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.nota_debito_compra_id_seq OWNED BY public.nota_debito_compra.id;


--
-- Name: nota_remision; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nota_remision (
    id integer NOT NULL,
    estado character varying(255),
    fecha timestamp without time zone,
    observacion character varying(255),
    tipo character varying(255),
    id_destino integer,
    id_estado integer,
    id_origen integer,
    id_pedido_compra integer,
    id_factura_compra integer,
    id_usuario integer
);


ALTER TABLE public.nota_remision OWNER TO postgres;

--
-- Name: nota_remision_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nota_remision_detalle (
    id integer NOT NULL,
    cantidad integer,
    estado character varying(255),
    id_articulo integer,
    id_pedido_compra_detalle integer,
    id_nota_remision integer
);


ALTER TABLE public.nota_remision_detalle OWNER TO postgres;

--
-- Name: nota_remision_detalle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.nota_remision_detalle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.nota_remision_detalle_id_seq OWNER TO postgres;

--
-- Name: nota_remision_detalle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.nota_remision_detalle_id_seq OWNED BY public.nota_remision_detalle.id;


--
-- Name: nota_remision_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.nota_remision_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.nota_remision_id_seq OWNER TO postgres;

--
-- Name: nota_remision_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.nota_remision_id_seq OWNED BY public.nota_remision.id;


--
-- Name: orden_compra; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orden_compra (
    id integer NOT NULL,
    cantidad_cuota integer,
    estado character varying(255),
    fecha timestamp without time zone,
    intervalo integer,
    monto bigint,
    monto_cuota bigint,
    observacion character varying(255),
    id_condicion_pago integer,
    id_estado integer,
    id_proveedor integer,
    id_usuario integer
);


ALTER TABLE public.orden_compra OWNER TO postgres;

--
-- Name: orden_compra_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orden_compra_detalle (
    id integer NOT NULL,
    estado character varying(255),
    monto bigint,
    id_presupueto_compra_detalle integer,
    id_orden_compra integer
);


ALTER TABLE public.orden_compra_detalle OWNER TO postgres;

--
-- Name: orden_compra_detalle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orden_compra_detalle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orden_compra_detalle_id_seq OWNER TO postgres;

--
-- Name: orden_compra_detalle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orden_compra_detalle_id_seq OWNED BY public.orden_compra_detalle.id;


--
-- Name: orden_compra_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orden_compra_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orden_compra_id_seq OWNER TO postgres;

--
-- Name: orden_compra_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orden_compra_id_seq OWNED BY public.orden_compra.id;


--
-- Name: orden_servicio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orden_servicio (
    id integer NOT NULL,
    estado character varying(255),
    fecha timestamp without time zone,
    fecha_entrega timestamp without time zone,
    observacion character varying(255),
    total bigint,
    vencimiento_garantia timestamp without time zone,
    id_estado integer,
    id_presupuesto_servicio integer,
    id_usuario integer,
    id_factura integer
);


ALTER TABLE public.orden_servicio OWNER TO postgres;

--
-- Name: orden_servicio_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orden_servicio_detalle (
    id integer NOT NULL,
    estado character varying(255),
    monto bigint,
    id_presupueto_servicio_detalle integer,
    id_orden_servicio integer
);


ALTER TABLE public.orden_servicio_detalle OWNER TO postgres;

--
-- Name: orden_servicio_detalle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orden_servicio_detalle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orden_servicio_detalle_id_seq OWNER TO postgres;

--
-- Name: orden_servicio_detalle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orden_servicio_detalle_id_seq OWNED BY public.orden_servicio_detalle.id;


--
-- Name: orden_servicio_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orden_servicio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orden_servicio_id_seq OWNER TO postgres;

--
-- Name: orden_servicio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orden_servicio_id_seq OWNED BY public.orden_servicio.id;


--
-- Name: pago; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pago (
    id integer NOT NULL,
    descripcion character varying(255),
    estado character varying(255),
    fecha timestamp without time zone,
    monto bigint
);


ALTER TABLE public.pago OWNER TO postgres;

--
-- Name: pago_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pago_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pago_id_seq OWNER TO postgres;

--
-- Name: pago_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pago_id_seq OWNED BY public.pago.id;


--
-- Name: pedido_compra; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pedido_compra (
    id integer NOT NULL,
    estado character varying(255),
    fecha timestamp without time zone,
    id_deposito integer,
    id_estado integer,
    id_usuario integer,
    observacion character varying
);


ALTER TABLE public.pedido_compra OWNER TO postgres;

--
-- Name: pedido_compra_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pedido_compra_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pedido_compra_id_seq OWNER TO postgres;

--
-- Name: pedido_compra_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pedido_compra_id_seq OWNED BY public.pedido_compra.id;


--
-- Name: pedido_venta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pedido_venta (
    id integer NOT NULL,
    estado character varying(255),
    fecha timestamp without time zone,
    observacion character varying(255),
    id_deposito integer,
    id_estado integer,
    id_usuario integer,
    id_cliente integer
);


ALTER TABLE public.pedido_venta OWNER TO postgres;

--
-- Name: pedido_venta_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pedido_venta_detalle (
    id integer NOT NULL,
    cantidad integer,
    estado character varying(255),
    id_articulo integer,
    id_pedido_venta integer
);


ALTER TABLE public.pedido_venta_detalle OWNER TO postgres;

--
-- Name: pedido_venta_detalle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pedido_venta_detalle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pedido_venta_detalle_id_seq OWNER TO postgres;

--
-- Name: pedido_venta_detalle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pedido_venta_detalle_id_seq OWNED BY public.pedido_venta_detalle.id;


--
-- Name: pedido_venta_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pedido_venta_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pedido_venta_id_seq OWNER TO postgres;

--
-- Name: pedido_venta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pedido_venta_id_seq OWNED BY public.pedido_venta.id;


--
-- Name: permiso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.permiso (
    id integer NOT NULL,
    id_rol integer,
    id_formulario integer,
    agregar boolean,
    modificar boolean,
    eliminar boolean,
    consultar boolean,
    listar boolean,
    informe boolean,
    exportar boolean,
    id_usuario_auditoria integer,
    estado character varying,
    reactivar boolean,
    anular boolean
);


ALTER TABLE public.permiso OWNER TO postgres;

--
-- Name: permisos_id_permiso_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.permisos_id_permiso_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permisos_id_permiso_seq OWNER TO postgres;

--
-- Name: permisos_id_permiso_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.permisos_id_permiso_seq OWNED BY public.permiso.id;


--
-- Name: presupuesto_compra; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.presupuesto_compra (
    id integer NOT NULL,
    estado character varying(255),
    fecha timestamp without time zone,
    observacion character varying(255),
    total bigint,
    id_estado integer,
    id_pedido_compra integer,
    id_usuario integer,
    id_proveedor integer,
    id_orden_compra integer
);


ALTER TABLE public.presupuesto_compra OWNER TO postgres;

--
-- Name: presupuesto_compra_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.presupuesto_compra_detalle (
    id integer NOT NULL,
    estado character varying(255),
    monto bigint,
    id_pedido_compra_detalle integer,
    id_presuesto_compra integer
);


ALTER TABLE public.presupuesto_compra_detalle OWNER TO postgres;

--
-- Name: presupuesto_compra_detalle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.presupuesto_compra_detalle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.presupuesto_compra_detalle_id_seq OWNER TO postgres;

--
-- Name: presupuesto_compra_detalle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.presupuesto_compra_detalle_id_seq OWNED BY public.presupuesto_compra_detalle.id;


--
-- Name: presupuesto_compra_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.presupuesto_compra_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.presupuesto_compra_id_seq OWNER TO postgres;

--
-- Name: presupuesto_compra_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.presupuesto_compra_id_seq OWNED BY public.presupuesto_compra.id;


--
-- Name: presupuesto_servicio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.presupuesto_servicio (
    id integer NOT NULL,
    estado character varying(255),
    fecha timestamp without time zone,
    observacion character varying(255),
    total bigint,
    id_diagnostico integer,
    id_estado integer,
    id_promo_descuento integer,
    id_usuario integer
);


ALTER TABLE public.presupuesto_servicio OWNER TO postgres;

--
-- Name: presupuesto_servicio_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.presupuesto_servicio_detalle (
    id integer NOT NULL,
    estado character varying(255),
    monto bigint,
    id_diagnostico_detalle integer,
    id_presuesto_servicio integer
);


ALTER TABLE public.presupuesto_servicio_detalle OWNER TO postgres;

--
-- Name: presupuesto_servicio_detalle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.presupuesto_servicio_detalle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.presupuesto_servicio_detalle_id_seq OWNER TO postgres;

--
-- Name: presupuesto_servicio_detalle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.presupuesto_servicio_detalle_id_seq OWNED BY public.presupuesto_servicio_detalle.id;


--
-- Name: presupuesto_servicio_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.presupuesto_servicio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.presupuesto_servicio_id_seq OWNER TO postgres;

--
-- Name: presupuesto_servicio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.presupuesto_servicio_id_seq OWNED BY public.presupuesto_servicio.id;


--
-- Name: promo_descuento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.promo_descuento (
    id integer NOT NULL,
    descripcion character varying(255),
    estado character varying(255),
    porcentaje bigint
);


ALTER TABLE public.promo_descuento OWNER TO postgres;

--
-- Name: promo_descuento_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.promo_descuento_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.promo_descuento_id_seq OWNER TO postgres;

--
-- Name: promo_descuento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.promo_descuento_id_seq OWNED BY public.promo_descuento.id;


--
-- Name: proveedor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.proveedor (
    id integer NOT NULL,
    razon_social character varying(50) NOT NULL,
    ruc character varying(60) NOT NULL,
    telefono character varying(60) NOT NULL,
    correo character varying(60) NOT NULL,
    direccion character varying(60) NOT NULL,
    id_ciudad integer NOT NULL,
    estado character varying
);


ALTER TABLE public.proveedor OWNER TO postgres;

--
-- Name: proveedor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.proveedor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.proveedor_id_seq OWNER TO postgres;

--
-- Name: proveedor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.proveedor_id_seq OWNED BY public.proveedor.id;


--
-- Name: proveedores_prove_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.proveedores_prove_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.proveedores_prove_id_seq OWNER TO postgres;

--
-- Name: proveedores_prove_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.proveedores_prove_id_seq OWNED BY public.proveedor.id;


--
-- Name: recepcion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recepcion (
    id integer NOT NULL,
    estado character varying(255),
    fecha timestamp without time zone,
    observacion character varying(255),
    id_estado integer,
    id_usuario integer,
    id_sucursal integer,
    id_cliente integer
);


ALTER TABLE public.recepcion OWNER TO postgres;

--
-- Name: recepcion_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recepcion_detalle (
    id integer NOT NULL,
    estado character varying(255),
    id_equipo integer,
    id_recepcion integer
);


ALTER TABLE public.recepcion_detalle OWNER TO postgres;

--
-- Name: recepcion_detalle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recepcion_detalle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recepcion_detalle_id_seq OWNER TO postgres;

--
-- Name: recepcion_detalle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recepcion_detalle_id_seq OWNED BY public.recepcion_detalle.id;


--
-- Name: recepcion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recepcion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recepcion_id_seq OWNER TO postgres;

--
-- Name: recepcion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recepcion_id_seq OWNED BY public.recepcion.id;


--
-- Name: rol; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rol (
    id integer NOT NULL,
    nombre character varying,
    id_usuario_auditoria integer,
    estado character varying
);


ALTER TABLE public.rol OWNER TO postgres;

--
-- Name: roles_id_rol_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_rol_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_rol_seq OWNER TO postgres;

--
-- Name: roles_id_rol_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_rol_seq OWNED BY public.rol.id;


--
-- Name: servicio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.servicio (
    id integer NOT NULL,
    descripcion character varying(255),
    estado character varying(255),
    monto bigint,
    id_impuesto integer,
    id_articulo integer
);


ALTER TABLE public.servicio OWNER TO postgres;

--
-- Name: servicio_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.servicio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.servicio_id_seq OWNER TO postgres;

--
-- Name: servicio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.servicio_id_seq OWNED BY public.servicio.id;


--
-- Name: servicios_por_diagnostico_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.servicios_por_diagnostico_detalle (
    id_diagnostico_detalle integer NOT NULL,
    id_servicio integer NOT NULL
);


ALTER TABLE public.servicios_por_diagnostico_detalle OWNER TO postgres;

--
-- Name: sistema; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sistema (
    id integer NOT NULL,
    nombre character varying,
    id_usuario_auditoria integer,
    estado character varying
);


ALTER TABLE public.sistema OWNER TO postgres;

--
-- Name: sistemas_id_sistema_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sistemas_id_sistema_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sistemas_id_sistema_seq OWNER TO postgres;

--
-- Name: sistemas_id_sistema_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sistemas_id_sistema_seq OWNED BY public.sistema.id;


--
-- Name: stock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock (
    id integer NOT NULL,
    estado character varying(255),
    existencia integer,
    id_articulo integer,
    id_deposito integer
);


ALTER TABLE public.stock OWNER TO postgres;

--
-- Name: stock_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stock_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stock_id_seq OWNER TO postgres;

--
-- Name: stock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stock_id_seq OWNED BY public.stock.id;


--
-- Name: sub_menu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sub_menu (
    id integer NOT NULL,
    nombre character varying,
    id_usuario_auditoria integer,
    estado character varying
);


ALTER TABLE public.sub_menu OWNER TO postgres;

--
-- Name: submenus_id_submenu_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.submenus_id_submenu_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.submenus_id_submenu_seq OWNER TO postgres;

--
-- Name: submenus_id_submenu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.submenus_id_submenu_seq OWNED BY public.sub_menu.id;


--
-- Name: sucursal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sucursal (
    id integer NOT NULL,
    descripcion character varying(250) NOT NULL,
    estado character varying,
    id_ciudad integer
);


ALTER TABLE public.sucursal OWNER TO postgres;

--
-- Name: sucursales_suc_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sucursales_suc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sucursales_suc_id_seq OWNER TO postgres;

--
-- Name: sucursales_suc_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sucursales_suc_id_seq OWNED BY public.sucursal.id;


--
-- Name: tarjeta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tarjeta (
    id integer NOT NULL,
    descripcion character varying(50) NOT NULL,
    estado character varying
);


ALTER TABLE public.tarjeta OWNER TO postgres;

--
-- Name: tarjeta_tarjeta_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tarjeta_tarjeta_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tarjeta_tarjeta_id_seq OWNER TO postgres;

--
-- Name: tarjeta_tarjeta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tarjeta_tarjeta_id_seq OWNED BY public.tarjeta.id;


--
-- Name: timbrado; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.timbrado (
    id integer NOT NULL,
    estado character varying,
    inicio_vigencia date,
    fin_vigencia date,
    numero character varying
);


ALTER TABLE public.timbrado OWNER TO postgres;

--
-- Name: timbrado_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.timbrado_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.timbrado_id_seq OWNER TO postgres;

--
-- Name: timbrado_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.timbrado_id_seq OWNED BY public.timbrado.id;


--
-- Name: tipo_articulo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_articulo (
    id integer NOT NULL,
    descripcion character varying NOT NULL,
    estado character varying
);


ALTER TABLE public.tipo_articulo OWNER TO postgres;

--
-- Name: tipo_articulo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_articulo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_articulo_id_seq OWNER TO postgres;

--
-- Name: tipo_articulo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_articulo_id_seq OWNED BY public.tipo_articulo.id;


--
-- Name: tipo_cheque; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_cheque (
    id integer NOT NULL,
    descripcion character varying,
    estado character varying
);


ALTER TABLE public.tipo_cheque OWNER TO postgres;

--
-- Name: tipo_cheque_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_cheque_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_cheque_id_seq OWNER TO postgres;

--
-- Name: tipo_cheque_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_cheque_id_seq OWNED BY public.tipo_cheque.id;


--
-- Name: tipo_documento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_documento (
    id integer NOT NULL,
    descripcion character varying,
    estado character varying
);


ALTER TABLE public.tipo_documento OWNER TO postgres;

--
-- Name: tipo_documento_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_documento_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_documento_id_seq OWNER TO postgres;

--
-- Name: tipo_documento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_documento_id_seq OWNED BY public.tipo_documento.id;


--
-- Name: tipo_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_item (
    id integer NOT NULL,
    descripcion character varying NOT NULL,
    estado character varying
);


ALTER TABLE public.tipo_item OWNER TO postgres;

--
-- Name: tipo_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_item_id_seq OWNER TO postgres;

--
-- Name: tipo_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_item_id_seq OWNED BY public.tipo_item.id;


--
-- Name: tipo_problema; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_problema (
    id integer NOT NULL,
    descripcion character varying(80) NOT NULL,
    estado character varying
);


ALTER TABLE public.tipo_problema OWNER TO postgres;

--
-- Name: tipo_problemas_tip_proble_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_problemas_tip_proble_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_problemas_tip_proble_id_seq OWNER TO postgres;

--
-- Name: tipo_problemas_tip_proble_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_problemas_tip_proble_id_seq OWNED BY public.tipo_problema.id;


--
-- Name: tipo_tarjeta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_tarjeta (
    id integer NOT NULL,
    descripcion character varying,
    estado character varying
);


ALTER TABLE public.tipo_tarjeta OWNER TO postgres;

--
-- Name: tipo_tarjeta_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_tarjeta_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_tarjeta_id_seq OWNER TO postgres;

--
-- Name: tipo_tarjeta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_tarjeta_id_seq OWNED BY public.tipo_tarjeta.id;


--
-- Name: usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuario (
    id integer NOT NULL,
    nombre character varying,
    usuario character varying,
    clave character varying,
    imagen character varying,
    id_usuario_auditoria integer,
    estado character varying,
    id_sucursal integer
);


ALTER TABLE public.usuario OWNER TO postgres;

--
-- Name: usuario_rol; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuario_rol (
    id integer NOT NULL,
    id_usuario integer,
    id_rol integer,
    id_usuario_auditoria integer,
    estado character varying
);


ALTER TABLE public.usuario_rol OWNER TO postgres;

--
-- Name: usuarios_id_usuario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuarios_id_usuario_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuarios_id_usuario_seq OWNER TO postgres;

--
-- Name: usuarios_id_usuario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuarios_id_usuario_seq OWNED BY public.usuario.id;


--
-- Name: usuariosroles_id_usuariorol_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuariosroles_id_usuariorol_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuariosroles_id_usuariorol_seq OWNER TO postgres;

--
-- Name: usuariosroles_id_usuariorol_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuariosroles_id_usuariorol_seq OWNED BY public.usuario_rol.id;


--
-- Name: ajuste id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ajuste ALTER COLUMN id SET DEFAULT nextval('public.ajuste_id_seq'::regclass);


--
-- Name: apertura_cierre_caja id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.apertura_cierre_caja ALTER COLUMN id SET DEFAULT nextval('public.apertura_cierre_caja_id_seq'::regclass);


--
-- Name: articulo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articulo ALTER COLUMN id SET DEFAULT nextval('public.articulo_id_seq'::regclass);


--
-- Name: banco id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banco ALTER COLUMN id SET DEFAULT nextval('public.banco_banco_id_seq'::regclass);


--
-- Name: banco_cheque id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banco_cheque ALTER COLUMN id SET DEFAULT nextval('public.banco_cheque_id_seq'::regclass);


--
-- Name: caja id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.caja ALTER COLUMN id SET DEFAULT nextval('public.caja_caja_id_seq'::regclass);


--
-- Name: cargo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cargo ALTER COLUMN id SET DEFAULT nextval('public.cargo_id_seq'::regclass);


--
-- Name: ciudad id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ciudad ALTER COLUMN id SET DEFAULT nextval('public.ciudad_id_seq'::regclass);


--
-- Name: cliente id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente ALTER COLUMN id SET DEFAULT nextval('public.cliente_id_seq'::regclass);


--
-- Name: cobro id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cobro ALTER COLUMN id SET DEFAULT nextval('public.cobro_id_seq'::regclass);


--
-- Name: condicion_pago id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.condicion_pago ALTER COLUMN id SET DEFAULT nextval('public.condicion_pago_id_seq'::regclass);


--
-- Name: cuenta_a_cobrar id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cuenta_a_cobrar ALTER COLUMN id SET DEFAULT nextval('public.cuenta_a_cobrar_id_seq'::regclass);


--
-- Name: cuenta_a_pagar id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cuenta_a_pagar ALTER COLUMN id SET DEFAULT nextval('public.cuenta_a_pagar_id_seq'::regclass);


--
-- Name: diagnostico id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diagnostico ALTER COLUMN id SET DEFAULT nextval('public.diagnostico_id_seq'::regclass);


--
-- Name: diagnostico_detalle id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diagnostico_detalle ALTER COLUMN id SET DEFAULT nextval('public.diagnostico_detalle_id_seq'::regclass);


--
-- Name: empresa id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empresa ALTER COLUMN id SET DEFAULT nextval('public.empresa_empre_id_seq'::regclass);


--
-- Name: encargado id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.encargado ALTER COLUMN id SET DEFAULT nextval('public.encargado_enca_id_seq'::regclass);


--
-- Name: entidad_emisora id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entidad_emisora ALTER COLUMN id SET DEFAULT nextval('public.entidad_emisora_id_seq'::regclass);


--
-- Name: equipo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipo ALTER COLUMN id SET DEFAULT nextval('public.equipos_equi_id_seq'::regclass);


--
-- Name: estado id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado ALTER COLUMN id SET DEFAULT nextval('public.estado_id_seq'::regclass);


--
-- Name: factura id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura ALTER COLUMN id SET DEFAULT nextval('public.factura_id_seq'::regclass);


--
-- Name: factura_compra id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura_compra ALTER COLUMN id SET DEFAULT nextval('public.factura_compra_id_seq'::regclass);


--
-- Name: factura_compra_detalle id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura_compra_detalle ALTER COLUMN id SET DEFAULT nextval('public.factura_compra_detalle_id_seq'::regclass);


--
-- Name: factura_detalle id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura_detalle ALTER COLUMN id SET DEFAULT nextval('public.factura_detalle_id_seq'::regclass);


--
-- Name: forma_cobro id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forma_cobro ALTER COLUMN id SET DEFAULT nextval('public.forma_cobro_form_id_seq'::regclass);


--
-- Name: formulario id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.formulario ALTER COLUMN id SET DEFAULT nextval('public.formularios_id_formulario_seq'::regclass);


--
-- Name: impuesto id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.impuesto ALTER COLUMN id SET DEFAULT nextval('public.impuesto_id_seq'::regclass);


--
-- Name: item id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item ALTER COLUMN id SET DEFAULT nextval('public.items_item_id_seq'::regclass);


--
-- Name: libro_compra id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.libro_compra ALTER COLUMN id SET DEFAULT nextval('public.libro_compra_id_seq'::regclass);


--
-- Name: libro_compra_detalle id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.libro_compra_detalle ALTER COLUMN id SET DEFAULT nextval('public.libro_compra_detalle_id_seq'::regclass);


--
-- Name: libro_venta id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.libro_venta ALTER COLUMN id SET DEFAULT nextval('public.libro_venta_id_seq'::regclass);


--
-- Name: libro_venta_detalle id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.libro_venta_detalle ALTER COLUMN id SET DEFAULT nextval('public.libro_venta_detalle_id_seq'::regclass);


--
-- Name: marca id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marca ALTER COLUMN id SET DEFAULT nextval('public.marcas_mar_id_seq'::regclass);


--
-- Name: motivo_ajuste id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.motivo_ajuste ALTER COLUMN id SET DEFAULT nextval('public.motivo_ajuste_maju_id_seq'::regclass);


--
-- Name: nota_credito_compra id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_credito_compra ALTER COLUMN id SET DEFAULT nextval('public.nota_credito_compra_id_seq'::regclass);


--
-- Name: nota_credito_compra_detalle id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_credito_compra_detalle ALTER COLUMN id SET DEFAULT nextval('public.nota_credito_compra_detalle_id_seq'::regclass);


--
-- Name: nota_debito_compra id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_debito_compra ALTER COLUMN id SET DEFAULT nextval('public.nota_debito_compra_id_seq'::regclass);


--
-- Name: nota_debito_compra_detalle id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_debito_compra_detalle ALTER COLUMN id SET DEFAULT nextval('public.nota_debito_compra_detalle_id_seq'::regclass);


--
-- Name: nota_remision id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_remision ALTER COLUMN id SET DEFAULT nextval('public.nota_remision_id_seq'::regclass);


--
-- Name: nota_remision_detalle id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_remision_detalle ALTER COLUMN id SET DEFAULT nextval('public.nota_remision_detalle_id_seq'::regclass);


--
-- Name: orden_compra id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden_compra ALTER COLUMN id SET DEFAULT nextval('public.orden_compra_id_seq'::regclass);


--
-- Name: orden_compra_detalle id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden_compra_detalle ALTER COLUMN id SET DEFAULT nextval('public.orden_compra_detalle_id_seq'::regclass);


--
-- Name: orden_servicio id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden_servicio ALTER COLUMN id SET DEFAULT nextval('public.orden_servicio_id_seq'::regclass);


--
-- Name: orden_servicio_detalle id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden_servicio_detalle ALTER COLUMN id SET DEFAULT nextval('public.orden_servicio_detalle_id_seq'::regclass);


--
-- Name: pago id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pago ALTER COLUMN id SET DEFAULT nextval('public.pago_id_seq'::regclass);


--
-- Name: pedido_compra id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_compra ALTER COLUMN id SET DEFAULT nextval('public.pedido_compra_id_seq'::regclass);


--
-- Name: pedido_compra_detalle id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_compra_detalle ALTER COLUMN id SET DEFAULT nextval('public.detalle_pedido_compra_id_seq'::regclass);


--
-- Name: pedido_venta id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_venta ALTER COLUMN id SET DEFAULT nextval('public.pedido_venta_id_seq'::regclass);


--
-- Name: pedido_venta_detalle id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_venta_detalle ALTER COLUMN id SET DEFAULT nextval('public.pedido_venta_detalle_id_seq'::regclass);


--
-- Name: permiso id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permiso ALTER COLUMN id SET DEFAULT nextval('public.permisos_id_permiso_seq'::regclass);


--
-- Name: persona id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona ALTER COLUMN id SET DEFAULT nextval('public.empleado_id_seq'::regclass);


--
-- Name: presupuesto_compra id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_compra ALTER COLUMN id SET DEFAULT nextval('public.presupuesto_compra_id_seq'::regclass);


--
-- Name: presupuesto_compra_detalle id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_compra_detalle ALTER COLUMN id SET DEFAULT nextval('public.presupuesto_compra_detalle_id_seq'::regclass);


--
-- Name: presupuesto_servicio id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_servicio ALTER COLUMN id SET DEFAULT nextval('public.presupuesto_servicio_id_seq'::regclass);


--
-- Name: presupuesto_servicio_detalle id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_servicio_detalle ALTER COLUMN id SET DEFAULT nextval('public.presupuesto_servicio_detalle_id_seq'::regclass);


--
-- Name: promo_descuento id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_descuento ALTER COLUMN id SET DEFAULT nextval('public.promo_descuento_id_seq'::regclass);


--
-- Name: proveedor id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proveedor ALTER COLUMN id SET DEFAULT nextval('public.proveedores_prove_id_seq'::regclass);


--
-- Name: recepcion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recepcion ALTER COLUMN id SET DEFAULT nextval('public.recepcion_id_seq'::regclass);


--
-- Name: recepcion_detalle id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recepcion_detalle ALTER COLUMN id SET DEFAULT nextval('public.recepcion_detalle_id_seq'::regclass);


--
-- Name: rol id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rol ALTER COLUMN id SET DEFAULT nextval('public.roles_id_rol_seq'::regclass);


--
-- Name: servicio id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.servicio ALTER COLUMN id SET DEFAULT nextval('public.servicio_id_seq'::regclass);


--
-- Name: sistema id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sistema ALTER COLUMN id SET DEFAULT nextval('public.sistemas_id_sistema_seq'::regclass);


--
-- Name: stock id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock ALTER COLUMN id SET DEFAULT nextval('public.stock_id_seq'::regclass);


--
-- Name: sub_menu id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_menu ALTER COLUMN id SET DEFAULT nextval('public.submenus_id_submenu_seq'::regclass);


--
-- Name: sucursal id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sucursal ALTER COLUMN id SET DEFAULT nextval('public.sucursales_suc_id_seq'::regclass);


--
-- Name: tarjeta id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tarjeta ALTER COLUMN id SET DEFAULT nextval('public.tarjeta_tarjeta_id_seq'::regclass);


--
-- Name: timbrado id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.timbrado ALTER COLUMN id SET DEFAULT nextval('public.timbrado_id_seq'::regclass);


--
-- Name: tipo_articulo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_articulo ALTER COLUMN id SET DEFAULT nextval('public.tipo_articulo_id_seq'::regclass);


--
-- Name: tipo_cheque id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_cheque ALTER COLUMN id SET DEFAULT nextval('public.tipo_cheque_id_seq'::regclass);


--
-- Name: tipo_documento id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_documento ALTER COLUMN id SET DEFAULT nextval('public.tipo_documento_id_seq'::regclass);


--
-- Name: tipo_item id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_item ALTER COLUMN id SET DEFAULT nextval('public.tipo_item_id_seq'::regclass);


--
-- Name: tipo_problema id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_problema ALTER COLUMN id SET DEFAULT nextval('public.tipo_problemas_tip_proble_id_seq'::regclass);


--
-- Name: tipo_tarjeta id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_tarjeta ALTER COLUMN id SET DEFAULT nextval('public.tipo_tarjeta_id_seq'::regclass);


--
-- Name: usuario id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_usuario_seq'::regclass);


--
-- Name: usuario_rol id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario_rol ALTER COLUMN id SET DEFAULT nextval('public.usuariosroles_id_usuariorol_seq'::regclass);


--
-- Data for Name: ajuste; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ajuste (id, cantidad, descripcion, estado, fecha, tipo, id_stock, id_estado) FROM stdin;
\.
COPY public.ajuste (id, cantidad, descripcion, estado, fecha, tipo, id_stock, id_estado) FROM '$$PATH$$/3933.dat';

--
-- Data for Name: apertura_cierre_caja; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.apertura_cierre_caja (id, descripcion, estado, fecha_hora_apertura, fecha_hora_cierre, monto_apertura, monto_cierre, monto_cierre_cheque, monto_cierre_efectivo, monto_cierre_tarjeta, id_caja, id_usuario) FROM stdin;
\.
COPY public.apertura_cierre_caja (id, descripcion, estado, fecha_hora_apertura, fecha_hora_cierre, monto_apertura, monto_cierre, monto_cierre_cheque, monto_cierre_efectivo, monto_cierre_tarjeta, id_caja, id_usuario) FROM '$$PATH$$/3935.dat';

--
-- Data for Name: articulo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.articulo (id, descripcion, precio_compra, precio_venta, codigo_generico, id_impuesto, id_marca, id_tipo_articulo, estado, precio_compra_anterior, precio_venta_anterior) FROM stdin;
\.
COPY public.articulo (id, descripcion, precio_compra, precio_venta, codigo_generico, id_impuesto, id_marca, id_tipo_articulo, estado, precio_compra_anterior, precio_venta_anterior) FROM '$$PATH$$/3937.dat';

--
-- Data for Name: banco; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.banco (id, descripcion, estado) FROM stdin;
\.
COPY public.banco (id, descripcion, estado) FROM '$$PATH$$/3939.dat';

--
-- Data for Name: banco_cheque; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.banco_cheque (id, descripcion, estado) FROM stdin;
\.
COPY public.banco_cheque (id, descripcion, estado) FROM '$$PATH$$/3941.dat';

--
-- Data for Name: caja; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.caja (id, descripcion, numero, estado, id_sucursal) FROM stdin;
\.
COPY public.caja (id, descripcion, numero, estado, id_sucursal) FROM '$$PATH$$/3943.dat';

--
-- Data for Name: cargo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cargo (id, descripcion, estado) FROM stdin;
\.
COPY public.cargo (id, descripcion, estado) FROM '$$PATH$$/3945.dat';

--
-- Data for Name: ciudad; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ciudad (id, descripcion, estado) FROM stdin;
\.
COPY public.ciudad (id, descripcion, estado) FROM '$$PATH$$/3947.dat';

--
-- Data for Name: cliente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cliente (id, correo, direccion, estado, razon, ruc, telefono, id_ciudad) FROM stdin;
\.
COPY public.cliente (id, correo, direccion, estado, razon, ruc, telefono, id_ciudad) FROM '$$PATH$$/3949.dat';

--
-- Data for Name: cobro; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cobro (id, descripcion, estado, fecha, monto) FROM stdin;
\.
COPY public.cobro (id, descripcion, estado, fecha, monto) FROM '$$PATH$$/3951.dat';

--
-- Data for Name: condicion_pago; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.condicion_pago (id, descripcion, estado) FROM stdin;
\.
COPY public.condicion_pago (id, descripcion, estado) FROM '$$PATH$$/3953.dat';

--
-- Data for Name: cuenta_a_cobrar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cuenta_a_cobrar (id, cantidad_cuotas, estado, fecha_vencimiento, monto, numero_cuota, id_cobro, id_estado, id_factura) FROM stdin;
\.
COPY public.cuenta_a_cobrar (id, cantidad_cuotas, estado, fecha_vencimiento, monto, numero_cuota, id_cobro, id_estado, id_factura) FROM '$$PATH$$/3955.dat';

--
-- Data for Name: cuenta_a_pagar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cuenta_a_pagar (id, cantidad_cuotas, estado, fecha_vencimiento, monto, numero_cuota, id_estado, id_pago) FROM stdin;
\.
COPY public.cuenta_a_pagar (id, cantidad_cuotas, estado, fecha_vencimiento, monto, numero_cuota, id_estado, id_pago) FROM '$$PATH$$/3957.dat';

--
-- Data for Name: deposito; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.deposito (id, descripcion, id_sucursal, estado) FROM stdin;
\.
COPY public.deposito (id, descripcion, id_sucursal, estado) FROM '$$PATH$$/3960.dat';

--
-- Data for Name: diagnostico; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.diagnostico (id, estado, fecha, observacion, id_estado, id_recepcion, id_usuario) FROM stdin;
\.
COPY public.diagnostico (id, estado, fecha, observacion, id_estado, id_recepcion, id_usuario) FROM '$$PATH$$/3963.dat';

--
-- Data for Name: diagnostico_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.diagnostico_detalle (id, diagnostico, estado, id_recepcion_detalle, id_diagnostico, id_servicio) FROM stdin;
\.
COPY public.diagnostico_detalle (id, diagnostico, estado, id_recepcion_detalle, id_diagnostico, id_servicio) FROM '$$PATH$$/3964.dat';

--
-- Data for Name: empresa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.empresa (id, telefono, direccion, nombre, ruc, estado) FROM stdin;
\.
COPY public.empresa (id, telefono, direccion, nombre, ruc, estado) FROM '$$PATH$$/3969.dat';

--
-- Data for Name: encargado; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.encargado (id, id_sucursal, nombre, apellido, direccion, telefono, email) FROM stdin;
\.
COPY public.encargado (id, id_sucursal, nombre, apellido, direccion, telefono, email) FROM '$$PATH$$/3971.dat';

--
-- Data for Name: entidad_emisora; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.entidad_emisora (id, descripcion, estado) FROM stdin;
\.
COPY public.entidad_emisora (id, descripcion, estado) FROM '$$PATH$$/3973.dat';

--
-- Data for Name: equipo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.equipo (id, serie, descripcion, modelo, id_marca, estado, id_cliente) FROM stdin;
\.
COPY public.equipo (id, serie, descripcion, modelo, id_marca, estado, id_cliente) FROM '$$PATH$$/3975.dat';

--
-- Data for Name: estado; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.estado (id, descripcion, estado) FROM stdin;
\.
COPY public.estado (id, descripcion, estado) FROM '$$PATH$$/3977.dat';

--
-- Data for Name: factura; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.factura (id, estado, fecha, monto, numerofactura, observacion, id_caja, id_condicion_pago, id_estado, id_libro_venta, id_pedido_venta, id_timbrado, id_usuario) FROM stdin;
\.
COPY public.factura (id, estado, fecha, monto, numerofactura, observacion, id_caja, id_condicion_pago, id_estado, id_libro_venta, id_pedido_venta, id_timbrado, id_usuario) FROM '$$PATH$$/3979.dat';

--
-- Data for Name: factura_compra; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.factura_compra (id, estado, fecha, monto, numero_factura, observacion, id_estado, id_libro_compra, id_orden_compra, id_usuario) FROM stdin;
\.
COPY public.factura_compra (id, estado, fecha, monto, numero_factura, observacion, id_estado, id_libro_compra, id_orden_compra, id_usuario) FROM '$$PATH$$/3980.dat';

--
-- Data for Name: factura_compra_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.factura_compra_detalle (id, estado, id_orden_compra_detalle, id_factura_compra) FROM stdin;
\.
COPY public.factura_compra_detalle (id, estado, id_orden_compra_detalle, id_factura_compra) FROM '$$PATH$$/3981.dat';

--
-- Data for Name: factura_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.factura_detalle (id, estado, monto, id_oreden_servicio_detalle, id_pedido_venta_detalle, id_factura) FROM stdin;
\.
COPY public.factura_detalle (id, estado, monto, id_oreden_servicio_detalle, id_pedido_venta_detalle, id_factura) FROM '$$PATH$$/3984.dat';

--
-- Data for Name: forma_cobro; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.forma_cobro (id, descripcion, estado) FROM stdin;
\.
COPY public.forma_cobro (id, descripcion, estado) FROM '$$PATH$$/3987.dat';

--
-- Data for Name: formulario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.formulario (id, nombre, url, id_sistema, id_sub_menu, id_usuario_auditoria, estado) FROM stdin;
\.
COPY public.formulario (id, nombre, url, id_sistema, id_sub_menu, id_usuario_auditoria, estado) FROM '$$PATH$$/3989.dat';

--
-- Data for Name: impuesto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.impuesto (id, descripcion, estado, porcentaje_impuesto) FROM stdin;
\.
COPY public.impuesto (id, descripcion, estado, porcentaje_impuesto) FROM '$$PATH$$/3991.dat';

--
-- Data for Name: item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item (id, descripcion, precio, stock, id_marca, estado) FROM stdin;
\.
COPY public.item (id, descripcion, precio, stock, id_marca, estado) FROM '$$PATH$$/3993.dat';

--
-- Data for Name: libro_compra; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.libro_compra (id, estado, fecha, monto_iva_10, monto_iva_5, montoneto) FROM stdin;
\.
COPY public.libro_compra (id, estado, fecha, monto_iva_10, monto_iva_5, montoneto) FROM '$$PATH$$/3995.dat';

--
-- Data for Name: libro_compra_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.libro_compra_detalle (id, estado, monto_impuesto, monto_neto, id_factura_compra_detalle, id_impuesto, id_libro_compra) FROM stdin;
\.
COPY public.libro_compra_detalle (id, estado, monto_impuesto, monto_neto, id_factura_compra_detalle, id_impuesto, id_libro_compra) FROM '$$PATH$$/3996.dat';

--
-- Data for Name: libro_venta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.libro_venta (id, estado, fecha, monto_iva_10, monto_iva_5, montoneto) FROM stdin;
\.
COPY public.libro_venta (id, estado, fecha, monto_iva_10, monto_iva_5, montoneto) FROM '$$PATH$$/3999.dat';

--
-- Data for Name: libro_venta_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.libro_venta_detalle (id, estado, monto_impuesto, monto_neto, id_factura_detalle, id_impuesto, id_libro_venta) FROM stdin;
\.
COPY public.libro_venta_detalle (id, estado, monto_impuesto, monto_neto, id_factura_detalle, id_impuesto, id_libro_venta) FROM '$$PATH$$/4000.dat';

--
-- Data for Name: marca; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.marca (id, descripcion, estado) FROM stdin;
\.
COPY public.marca (id, descripcion, estado) FROM '$$PATH$$/4003.dat';

--
-- Data for Name: motivo_ajuste; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.motivo_ajuste (id, descripcion, estado) FROM stdin;
\.
COPY public.motivo_ajuste (id, descripcion, estado) FROM '$$PATH$$/4005.dat';

--
-- Data for Name: nota_credito_compra; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.nota_credito_compra (id, estado, fecha, monto, observacion, id_estado, id_factura_compra, id_proveedor, id_orden_compra_cancelacion, id_usuario) FROM stdin;
\.
COPY public.nota_credito_compra (id, estado, fecha, monto, observacion, id_estado, id_factura_compra, id_proveedor, id_orden_compra_cancelacion, id_usuario) FROM '$$PATH$$/4007.dat';

--
-- Data for Name: nota_credito_compra_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.nota_credito_compra_detalle (id, cantidad, estado, monto, id_articulo, id_nota_credito_compra) FROM stdin;
\.
COPY public.nota_credito_compra_detalle (id, cantidad, estado, monto, id_articulo, id_nota_credito_compra) FROM '$$PATH$$/4008.dat';

--
-- Data for Name: nota_debito_compra; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.nota_debito_compra (id, estado, monto, numero, observacion, id_cuenta_a_pagar, id_estado, id_factura_compra) FROM stdin;
\.
COPY public.nota_debito_compra (id, estado, monto, numero, observacion, id_cuenta_a_pagar, id_estado, id_factura_compra) FROM '$$PATH$$/4011.dat';

--
-- Data for Name: nota_debito_compra_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.nota_debito_compra_detalle (id, estado, id_factura_compra_detalle, id_nota_debito) FROM stdin;
\.
COPY public.nota_debito_compra_detalle (id, estado, id_factura_compra_detalle, id_nota_debito) FROM '$$PATH$$/4012.dat';

--
-- Data for Name: nota_remision; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.nota_remision (id, estado, fecha, observacion, tipo, id_destino, id_estado, id_origen, id_pedido_compra, id_factura_compra, id_usuario) FROM stdin;
\.
COPY public.nota_remision (id, estado, fecha, observacion, tipo, id_destino, id_estado, id_origen, id_pedido_compra, id_factura_compra, id_usuario) FROM '$$PATH$$/4015.dat';

--
-- Data for Name: nota_remision_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.nota_remision_detalle (id, cantidad, estado, id_articulo, id_pedido_compra_detalle, id_nota_remision) FROM stdin;
\.
COPY public.nota_remision_detalle (id, cantidad, estado, id_articulo, id_pedido_compra_detalle, id_nota_remision) FROM '$$PATH$$/4016.dat';

--
-- Data for Name: orden_compra; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orden_compra (id, cantidad_cuota, estado, fecha, intervalo, monto, monto_cuota, observacion, id_condicion_pago, id_estado, id_proveedor, id_usuario) FROM stdin;
\.
COPY public.orden_compra (id, cantidad_cuota, estado, fecha, intervalo, monto, monto_cuota, observacion, id_condicion_pago, id_estado, id_proveedor, id_usuario) FROM '$$PATH$$/4019.dat';

--
-- Data for Name: orden_compra_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orden_compra_detalle (id, estado, monto, id_presupueto_compra_detalle, id_orden_compra) FROM stdin;
\.
COPY public.orden_compra_detalle (id, estado, monto, id_presupueto_compra_detalle, id_orden_compra) FROM '$$PATH$$/4020.dat';

--
-- Data for Name: orden_servicio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orden_servicio (id, estado, fecha, fecha_entrega, observacion, total, vencimiento_garantia, id_estado, id_presupuesto_servicio, id_usuario, id_factura) FROM stdin;
\.
COPY public.orden_servicio (id, estado, fecha, fecha_entrega, observacion, total, vencimiento_garantia, id_estado, id_presupuesto_servicio, id_usuario, id_factura) FROM '$$PATH$$/4023.dat';

--
-- Data for Name: orden_servicio_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orden_servicio_detalle (id, estado, monto, id_presupueto_servicio_detalle, id_orden_servicio) FROM stdin;
\.
COPY public.orden_servicio_detalle (id, estado, monto, id_presupueto_servicio_detalle, id_orden_servicio) FROM '$$PATH$$/4024.dat';

--
-- Data for Name: pago; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pago (id, descripcion, estado, fecha, monto) FROM stdin;
\.
COPY public.pago (id, descripcion, estado, fecha, monto) FROM '$$PATH$$/4027.dat';

--
-- Data for Name: pedido_compra; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pedido_compra (id, estado, fecha, id_deposito, id_estado, id_usuario, observacion) FROM stdin;
\.
COPY public.pedido_compra (id, estado, fecha, id_deposito, id_estado, id_usuario, observacion) FROM '$$PATH$$/4029.dat';

--
-- Data for Name: pedido_compra_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pedido_compra_detalle (id, cantidad, estado, id_articulo, id_pedido_compra) FROM stdin;
\.
COPY public.pedido_compra_detalle (id, cantidad, estado, id_articulo, id_pedido_compra) FROM '$$PATH$$/3961.dat';

--
-- Data for Name: pedido_venta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pedido_venta (id, estado, fecha, observacion, id_deposito, id_estado, id_usuario, id_cliente) FROM stdin;
\.
COPY public.pedido_venta (id, estado, fecha, observacion, id_deposito, id_estado, id_usuario, id_cliente) FROM '$$PATH$$/4031.dat';

--
-- Data for Name: pedido_venta_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pedido_venta_detalle (id, cantidad, estado, id_articulo, id_pedido_venta) FROM stdin;
\.
COPY public.pedido_venta_detalle (id, cantidad, estado, id_articulo, id_pedido_venta) FROM '$$PATH$$/4032.dat';

--
-- Data for Name: permiso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.permiso (id, id_rol, id_formulario, agregar, modificar, eliminar, consultar, listar, informe, exportar, id_usuario_auditoria, estado, reactivar, anular) FROM stdin;
\.
COPY public.permiso (id, id_rol, id_formulario, agregar, modificar, eliminar, consultar, listar, informe, exportar, id_usuario_auditoria, estado, reactivar, anular) FROM '$$PATH$$/4035.dat';

--
-- Data for Name: persona; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.persona (id, nombre, apellido, ci, telefono, direccion, id_ciudad, estado) FROM stdin;
\.
COPY public.persona (id, nombre, apellido, ci, telefono, direccion, id_ciudad, estado) FROM '$$PATH$$/3967.dat';

--
-- Data for Name: presupuesto_compra; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.presupuesto_compra (id, estado, fecha, observacion, total, id_estado, id_pedido_compra, id_usuario, id_proveedor, id_orden_compra) FROM stdin;
\.
COPY public.presupuesto_compra (id, estado, fecha, observacion, total, id_estado, id_pedido_compra, id_usuario, id_proveedor, id_orden_compra) FROM '$$PATH$$/4037.dat';

--
-- Data for Name: presupuesto_compra_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.presupuesto_compra_detalle (id, estado, monto, id_pedido_compra_detalle, id_presuesto_compra) FROM stdin;
\.
COPY public.presupuesto_compra_detalle (id, estado, monto, id_pedido_compra_detalle, id_presuesto_compra) FROM '$$PATH$$/4038.dat';

--
-- Data for Name: presupuesto_servicio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.presupuesto_servicio (id, estado, fecha, observacion, total, id_diagnostico, id_estado, id_promo_descuento, id_usuario) FROM stdin;
\.
COPY public.presupuesto_servicio (id, estado, fecha, observacion, total, id_diagnostico, id_estado, id_promo_descuento, id_usuario) FROM '$$PATH$$/4041.dat';

--
-- Data for Name: presupuesto_servicio_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.presupuesto_servicio_detalle (id, estado, monto, id_diagnostico_detalle, id_presuesto_servicio) FROM stdin;
\.
COPY public.presupuesto_servicio_detalle (id, estado, monto, id_diagnostico_detalle, id_presuesto_servicio) FROM '$$PATH$$/4042.dat';

--
-- Data for Name: promo_descuento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.promo_descuento (id, descripcion, estado, porcentaje) FROM stdin;
\.
COPY public.promo_descuento (id, descripcion, estado, porcentaje) FROM '$$PATH$$/4045.dat';

--
-- Data for Name: proveedor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.proveedor (id, razon_social, ruc, telefono, correo, direccion, id_ciudad, estado) FROM stdin;
\.
COPY public.proveedor (id, razon_social, ruc, telefono, correo, direccion, id_ciudad, estado) FROM '$$PATH$$/4047.dat';

--
-- Data for Name: recepcion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recepcion (id, estado, fecha, observacion, id_estado, id_usuario, id_sucursal, id_cliente) FROM stdin;
\.
COPY public.recepcion (id, estado, fecha, observacion, id_estado, id_usuario, id_sucursal, id_cliente) FROM '$$PATH$$/4050.dat';

--
-- Data for Name: recepcion_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recepcion_detalle (id, estado, id_equipo, id_recepcion) FROM stdin;
\.
COPY public.recepcion_detalle (id, estado, id_equipo, id_recepcion) FROM '$$PATH$$/4051.dat';

--
-- Data for Name: rol; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rol (id, nombre, id_usuario_auditoria, estado) FROM stdin;
\.
COPY public.rol (id, nombre, id_usuario_auditoria, estado) FROM '$$PATH$$/4054.dat';

--
-- Data for Name: servicio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.servicio (id, descripcion, estado, monto, id_impuesto, id_articulo) FROM stdin;
\.
COPY public.servicio (id, descripcion, estado, monto, id_impuesto, id_articulo) FROM '$$PATH$$/4056.dat';

--
-- Data for Name: servicios_por_diagnostico_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.servicios_por_diagnostico_detalle (id_diagnostico_detalle, id_servicio) FROM stdin;
\.
COPY public.servicios_por_diagnostico_detalle (id_diagnostico_detalle, id_servicio) FROM '$$PATH$$/4058.dat';

--
-- Data for Name: sistema; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sistema (id, nombre, id_usuario_auditoria, estado) FROM stdin;
\.
COPY public.sistema (id, nombre, id_usuario_auditoria, estado) FROM '$$PATH$$/4059.dat';

--
-- Data for Name: stock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock (id, estado, existencia, id_articulo, id_deposito) FROM stdin;
\.
COPY public.stock (id, estado, existencia, id_articulo, id_deposito) FROM '$$PATH$$/4061.dat';

--
-- Data for Name: sub_menu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sub_menu (id, nombre, id_usuario_auditoria, estado) FROM stdin;
\.
COPY public.sub_menu (id, nombre, id_usuario_auditoria, estado) FROM '$$PATH$$/4063.dat';

--
-- Data for Name: sucursal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sucursal (id, descripcion, estado, id_ciudad) FROM stdin;
\.
COPY public.sucursal (id, descripcion, estado, id_ciudad) FROM '$$PATH$$/4065.dat';

--
-- Data for Name: tarjeta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tarjeta (id, descripcion, estado) FROM stdin;
\.
COPY public.tarjeta (id, descripcion, estado) FROM '$$PATH$$/4067.dat';

--
-- Data for Name: timbrado; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.timbrado (id, estado, inicio_vigencia, fin_vigencia, numero) FROM stdin;
\.
COPY public.timbrado (id, estado, inicio_vigencia, fin_vigencia, numero) FROM '$$PATH$$/4086.dat';

--
-- Data for Name: tipo_articulo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipo_articulo (id, descripcion, estado) FROM stdin;
\.
COPY public.tipo_articulo (id, descripcion, estado) FROM '$$PATH$$/4069.dat';

--
-- Data for Name: tipo_cheque; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipo_cheque (id, descripcion, estado) FROM stdin;
\.
COPY public.tipo_cheque (id, descripcion, estado) FROM '$$PATH$$/4071.dat';

--
-- Data for Name: tipo_documento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipo_documento (id, descripcion, estado) FROM stdin;
\.
COPY public.tipo_documento (id, descripcion, estado) FROM '$$PATH$$/4073.dat';

--
-- Data for Name: tipo_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipo_item (id, descripcion, estado) FROM stdin;
\.
COPY public.tipo_item (id, descripcion, estado) FROM '$$PATH$$/4075.dat';

--
-- Data for Name: tipo_problema; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipo_problema (id, descripcion, estado) FROM stdin;
\.
COPY public.tipo_problema (id, descripcion, estado) FROM '$$PATH$$/4077.dat';

--
-- Data for Name: tipo_tarjeta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipo_tarjeta (id, descripcion, estado) FROM stdin;
\.
COPY public.tipo_tarjeta (id, descripcion, estado) FROM '$$PATH$$/4079.dat';

--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuario (id, nombre, usuario, clave, imagen, id_usuario_auditoria, estado, id_sucursal) FROM stdin;
\.
COPY public.usuario (id, nombre, usuario, clave, imagen, id_usuario_auditoria, estado, id_sucursal) FROM '$$PATH$$/4081.dat';

--
-- Data for Name: usuario_rol; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuario_rol (id, id_usuario, id_rol, id_usuario_auditoria, estado) FROM stdin;
\.
COPY public.usuario_rol (id, id_usuario, id_rol, id_usuario_auditoria, estado) FROM '$$PATH$$/4082.dat';

--
-- Name: ajuste_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ajuste_id_seq', 3, true);


--
-- Name: apertura_cierre_caja_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.apertura_cierre_caja_id_seq', 2, true);


--
-- Name: articulo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.articulo_id_seq', 10, true);


--
-- Name: banco_banco_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.banco_banco_id_seq', 2, true);


--
-- Name: banco_cheque_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.banco_cheque_id_seq', 1, false);


--
-- Name: caja_caja_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.caja_caja_id_seq', 11, true);


--
-- Name: cargo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cargo_id_seq', 3, true);


--
-- Name: ciudad_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ciudad_id_seq', 6, true);


--
-- Name: cliente_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cliente_id_seq', 2, true);


--
-- Name: cobro_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cobro_id_seq', 1, false);


--
-- Name: condicion_pago_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.condicion_pago_id_seq', 3, true);


--
-- Name: cuenta_a_cobrar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cuenta_a_cobrar_id_seq', 1, false);


--
-- Name: cuenta_a_pagar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cuenta_a_pagar_id_seq', 86, true);


--
-- Name: deposito_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.deposito_id_seq', 12, true);


--
-- Name: detalle_pedido_compra_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.detalle_pedido_compra_id_seq', 24, true);


--
-- Name: diagnostico_detalle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.diagnostico_detalle_id_seq', 16, true);


--
-- Name: diagnostico_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.diagnostico_id_seq', 10, true);


--
-- Name: empleado_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.empleado_id_seq', 1, false);


--
-- Name: empresa_empre_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.empresa_empre_id_seq', 6, true);


--
-- Name: encargado_enca_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.encargado_enca_id_seq', 3, true);


--
-- Name: entidad_emisora_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.entidad_emisora_id_seq', 2, true);


--
-- Name: equipos_equi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.equipos_equi_id_seq', 18, true);


--
-- Name: estado_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.estado_id_seq', 9, true);


--
-- Name: factura_compra_detalle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.factura_compra_detalle_id_seq', 29, true);


--
-- Name: factura_compra_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.factura_compra_id_seq', 13, true);


--
-- Name: factura_detalle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.factura_detalle_id_seq', 6, true);


--
-- Name: factura_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.factura_id_seq', 3, true);


--
-- Name: forma_cobro_form_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.forma_cobro_form_id_seq', 4, true);


--
-- Name: formularios_id_formulario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.formularios_id_formulario_seq', 59, true);


--
-- Name: impuesto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.impuesto_id_seq', 4, true);


--
-- Name: items_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.items_item_id_seq', 3, true);


--
-- Name: libro_compra_detalle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.libro_compra_detalle_id_seq', 29, true);


--
-- Name: libro_compra_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.libro_compra_id_seq', 13, true);


--
-- Name: libro_venta_detalle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.libro_venta_detalle_id_seq', 6, true);


--
-- Name: libro_venta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.libro_venta_id_seq', 3, true);


--
-- Name: marcas_mar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.marcas_mar_id_seq', 38, true);


--
-- Name: motivo_ajuste_maju_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.motivo_ajuste_maju_id_seq', 2, true);


--
-- Name: nota_credito_compra_detalle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.nota_credito_compra_detalle_id_seq', 8, true);


--
-- Name: nota_credito_compra_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.nota_credito_compra_id_seq', 6, true);


--
-- Name: nota_debito_compra_detalle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.nota_debito_compra_detalle_id_seq', 219, true);


--
-- Name: nota_debito_compra_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.nota_debito_compra_id_seq', 86, true);


--
-- Name: nota_remision_detalle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.nota_remision_detalle_id_seq', 37, true);


--
-- Name: nota_remision_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.nota_remision_id_seq', 26, true);


--
-- Name: orden_compra_detalle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orden_compra_detalle_id_seq', 31, true);


--
-- Name: orden_compra_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orden_compra_id_seq', 18, true);


--
-- Name: orden_servicio_detalle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orden_servicio_detalle_id_seq', 5, true);


--
-- Name: orden_servicio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orden_servicio_id_seq', 4, true);


--
-- Name: pago_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pago_id_seq', 4, true);


--
-- Name: pedido_compra_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pedido_compra_id_seq', 19, true);


--
-- Name: pedido_venta_detalle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pedido_venta_detalle_id_seq', 3, true);


--
-- Name: pedido_venta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pedido_venta_id_seq', 2, true);


--
-- Name: permisos_id_permiso_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.permisos_id_permiso_seq', 61, true);


--
-- Name: presupuesto_compra_detalle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.presupuesto_compra_detalle_id_seq', 22, true);


--
-- Name: presupuesto_compra_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.presupuesto_compra_id_seq', 18, true);


--
-- Name: presupuesto_servicio_detalle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.presupuesto_servicio_detalle_id_seq', 10, true);


--
-- Name: presupuesto_servicio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.presupuesto_servicio_id_seq', 6, true);


--
-- Name: promo_descuento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.promo_descuento_id_seq', 4, true);


--
-- Name: proveedor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.proveedor_id_seq', 1, false);


--
-- Name: proveedores_prove_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.proveedores_prove_id_seq', 5, true);


--
-- Name: recepcion_detalle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recepcion_detalle_id_seq', 10, true);


--
-- Name: recepcion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recepcion_id_seq', 8, true);


--
-- Name: roles_id_rol_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_rol_seq', 44, true);


--
-- Name: servicio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.servicio_id_seq', 8, true);


--
-- Name: sistemas_id_sistema_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sistemas_id_sistema_seq', 3, true);


--
-- Name: stock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stock_id_seq', 18, true);


--
-- Name: submenus_id_submenu_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.submenus_id_submenu_seq', 1, false);


--
-- Name: sucursales_suc_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sucursales_suc_id_seq', 14, true);


--
-- Name: tarjeta_tarjeta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tarjeta_tarjeta_id_seq', 2, true);


--
-- Name: timbrado_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.timbrado_id_seq', 2, true);


--
-- Name: tipo_articulo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_articulo_id_seq', 3, true);


--
-- Name: tipo_cheque_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_cheque_id_seq', 1, false);


--
-- Name: tipo_documento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_documento_id_seq', 1, false);


--
-- Name: tipo_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_item_id_seq', 1, false);


--
-- Name: tipo_problemas_tip_proble_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_problemas_tip_proble_id_seq', 2, true);


--
-- Name: tipo_tarjeta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_tarjeta_id_seq', 3, true);


--
-- Name: usuarios_id_usuario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuarios_id_usuario_seq', 4, true);


--
-- Name: usuariosroles_id_usuariorol_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuariosroles_id_usuariorol_seq', 9, true);


--
-- Name: ajuste ajuste_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ajuste
    ADD CONSTRAINT ajuste_pkey PRIMARY KEY (id);


--
-- Name: apertura_cierre_caja apertura_cierre_caja_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.apertura_cierre_caja
    ADD CONSTRAINT apertura_cierre_caja_pkey PRIMARY KEY (id);


--
-- Name: articulo articulo_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articulo
    ADD CONSTRAINT articulo_pk PRIMARY KEY (id);


--
-- Name: articulo articulo_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articulo
    ADD CONSTRAINT articulo_un UNIQUE (descripcion);


--
-- Name: banco_cheque banco_cheque_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banco_cheque
    ADD CONSTRAINT banco_cheque_pk PRIMARY KEY (id);


--
-- Name: banco_cheque banco_cheque_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banco_cheque
    ADD CONSTRAINT banco_cheque_un UNIQUE (descripcion);


--
-- Name: banco banco_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banco
    ADD CONSTRAINT banco_pkey PRIMARY KEY (id);


--
-- Name: banco banco_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banco
    ADD CONSTRAINT banco_un UNIQUE (descripcion);


--
-- Name: caja caja_caja_nro_caja_nro1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.caja
    ADD CONSTRAINT caja_caja_nro_caja_nro1_key UNIQUE (numero) INCLUDE (numero);


--
-- Name: caja caja_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.caja
    ADD CONSTRAINT caja_pkey PRIMARY KEY (id);


--
-- Name: cargo cargo_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cargo
    ADD CONSTRAINT cargo_pk PRIMARY KEY (id);


--
-- Name: cargo cargo_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cargo
    ADD CONSTRAINT cargo_un UNIQUE (descripcion);


--
-- Name: ciudad ciudad_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ciudad
    ADD CONSTRAINT ciudad_pk PRIMARY KEY (id);


--
-- Name: ciudad ciudad_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ciudad
    ADD CONSTRAINT ciudad_un UNIQUE (descripcion);


--
-- Name: cliente cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_pkey PRIMARY KEY (id);


--
-- Name: cobro cobro_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cobro
    ADD CONSTRAINT cobro_pkey PRIMARY KEY (id);


--
-- Name: condicion_pago condicion_pago_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.condicion_pago
    ADD CONSTRAINT condicion_pago_pk PRIMARY KEY (id);


--
-- Name: condicion_pago condicion_pago_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.condicion_pago
    ADD CONSTRAINT condicion_pago_un UNIQUE (descripcion);


--
-- Name: cuenta_a_cobrar cuenta_a_cobrar_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cuenta_a_cobrar
    ADD CONSTRAINT cuenta_a_cobrar_pkey PRIMARY KEY (id);


--
-- Name: cuenta_a_pagar cuenta_a_pagar_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cuenta_a_pagar
    ADD CONSTRAINT cuenta_a_pagar_pkey PRIMARY KEY (id);


--
-- Name: deposito deposito_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deposito
    ADD CONSTRAINT deposito_pk PRIMARY KEY (id);


--
-- Name: deposito deposito_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deposito
    ADD CONSTRAINT deposito_un UNIQUE (descripcion);


--
-- Name: pedido_compra_detalle detalle_pedido_compra_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_compra_detalle
    ADD CONSTRAINT detalle_pedido_compra_pkey PRIMARY KEY (id);


--
-- Name: diagnostico_detalle diagnostico_detalle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diagnostico_detalle
    ADD CONSTRAINT diagnostico_detalle_pkey PRIMARY KEY (id);


--
-- Name: diagnostico diagnostico_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diagnostico
    ADD CONSTRAINT diagnostico_pkey PRIMARY KEY (id);


--
-- Name: empresa empresa_empre_ruc_empre_ruc1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empresa
    ADD CONSTRAINT empresa_empre_ruc_empre_ruc1_key UNIQUE (ruc) INCLUDE (ruc);


--
-- Name: empresa empresa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empresa
    ADD CONSTRAINT empresa_pkey PRIMARY KEY (id);


--
-- Name: encargado encargado_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.encargado
    ADD CONSTRAINT encargado_pkey PRIMARY KEY (id);


--
-- Name: entidad_emisora entidad_emisora_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entidad_emisora
    ADD CONSTRAINT entidad_emisora_pk PRIMARY KEY (id);


--
-- Name: entidad_emisora entidad_emisora_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entidad_emisora
    ADD CONSTRAINT entidad_emisora_un UNIQUE (descripcion);


--
-- Name: equipo equipos_equi_serie_equi_serie1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipo
    ADD CONSTRAINT equipos_equi_serie_equi_serie1_key UNIQUE (serie) INCLUDE (serie);


--
-- Name: equipo equipos_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipo
    ADD CONSTRAINT equipos_pk PRIMARY KEY (id);


--
-- Name: estado estado_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado
    ADD CONSTRAINT estado_pk PRIMARY KEY (id);


--
-- Name: estado estado_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado
    ADD CONSTRAINT estado_un UNIQUE (descripcion);


--
-- Name: factura_compra_detalle factura_compra_detalle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura_compra_detalle
    ADD CONSTRAINT factura_compra_detalle_pkey PRIMARY KEY (id);


--
-- Name: factura_compra factura_compra_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura_compra
    ADD CONSTRAINT factura_compra_pkey PRIMARY KEY (id);


--
-- Name: factura_detalle factura_detalle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura_detalle
    ADD CONSTRAINT factura_detalle_pkey PRIMARY KEY (id);


--
-- Name: factura factura_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura
    ADD CONSTRAINT factura_pkey PRIMARY KEY (id);


--
-- Name: forma_cobro forma_cobro_form_descri_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forma_cobro
    ADD CONSTRAINT forma_cobro_form_descri_key UNIQUE (descripcion);


--
-- Name: forma_cobro forma_cobro_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forma_cobro
    ADD CONSTRAINT forma_cobro_pkey PRIMARY KEY (id);


--
-- Name: formulario formularios_id_formulario_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.formulario
    ADD CONSTRAINT formularios_id_formulario_pk PRIMARY KEY (id);


--
-- Name: formulario formularios_url_formulario_url_formulario1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.formulario
    ADD CONSTRAINT formularios_url_formulario_url_formulario1_key UNIQUE (url) INCLUDE (url);


--
-- Name: impuesto impuesto_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.impuesto
    ADD CONSTRAINT impuesto_pk PRIMARY KEY (id);


--
-- Name: impuesto impuesto_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.impuesto
    ADD CONSTRAINT impuesto_un UNIQUE (descripcion);


--
-- Name: item item_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item
    ADD CONSTRAINT item_pk PRIMARY KEY (id);


--
-- Name: item items_item_descri_item_descri1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item
    ADD CONSTRAINT items_item_descri_item_descri1_key UNIQUE (descripcion) INCLUDE (descripcion);


--
-- Name: libro_compra_detalle libro_compra_detalle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.libro_compra_detalle
    ADD CONSTRAINT libro_compra_detalle_pkey PRIMARY KEY (id);


--
-- Name: libro_compra libro_compra_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.libro_compra
    ADD CONSTRAINT libro_compra_pkey PRIMARY KEY (id);


--
-- Name: libro_venta_detalle libro_venta_detalle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.libro_venta_detalle
    ADD CONSTRAINT libro_venta_detalle_pkey PRIMARY KEY (id);


--
-- Name: libro_venta libro_venta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.libro_venta
    ADD CONSTRAINT libro_venta_pkey PRIMARY KEY (id);


--
-- Name: marca marca_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marca
    ADD CONSTRAINT marca_un UNIQUE (descripcion);


--
-- Name: marca marcas_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marca
    ADD CONSTRAINT marcas_pk PRIMARY KEY (id);


--
-- Name: motivo_ajuste motivo_ajuste_maju_descri_maju_descri1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.motivo_ajuste
    ADD CONSTRAINT motivo_ajuste_maju_descri_maju_descri1_key UNIQUE (descripcion) INCLUDE (descripcion);


--
-- Name: motivo_ajuste motivo_ajuste_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.motivo_ajuste
    ADD CONSTRAINT motivo_ajuste_pkey PRIMARY KEY (id);


--
-- Name: nota_credito_compra_detalle nota_credito_compra_detalle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_credito_compra_detalle
    ADD CONSTRAINT nota_credito_compra_detalle_pkey PRIMARY KEY (id);


--
-- Name: nota_credito_compra nota_credito_compra_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_credito_compra
    ADD CONSTRAINT nota_credito_compra_pkey PRIMARY KEY (id);


--
-- Name: nota_debito_compra_detalle nota_debito_compra_detalle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_debito_compra_detalle
    ADD CONSTRAINT nota_debito_compra_detalle_pkey PRIMARY KEY (id);


--
-- Name: nota_debito_compra nota_debito_compra_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_debito_compra
    ADD CONSTRAINT nota_debito_compra_pkey PRIMARY KEY (id);


--
-- Name: nota_remision_detalle nota_remision_detalle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_remision_detalle
    ADD CONSTRAINT nota_remision_detalle_pkey PRIMARY KEY (id);


--
-- Name: nota_remision nota_remision_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_remision
    ADD CONSTRAINT nota_remision_pkey PRIMARY KEY (id);


--
-- Name: orden_compra_detalle orden_compra_detalle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden_compra_detalle
    ADD CONSTRAINT orden_compra_detalle_pkey PRIMARY KEY (id);


--
-- Name: orden_compra orden_compra_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden_compra
    ADD CONSTRAINT orden_compra_pkey PRIMARY KEY (id);


--
-- Name: orden_servicio_detalle orden_servicio_detalle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden_servicio_detalle
    ADD CONSTRAINT orden_servicio_detalle_pkey PRIMARY KEY (id);


--
-- Name: orden_servicio orden_servicio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden_servicio
    ADD CONSTRAINT orden_servicio_pkey PRIMARY KEY (id);


--
-- Name: pago pago_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pago
    ADD CONSTRAINT pago_pkey PRIMARY KEY (id);


--
-- Name: pedido_compra pedido_compra_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_compra
    ADD CONSTRAINT pedido_compra_pkey PRIMARY KEY (id);


--
-- Name: pedido_venta_detalle pedido_venta_detalle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_venta_detalle
    ADD CONSTRAINT pedido_venta_detalle_pkey PRIMARY KEY (id);


--
-- Name: pedido_venta pedido_venta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_venta
    ADD CONSTRAINT pedido_venta_pkey PRIMARY KEY (id);


--
-- Name: permiso permisos_id_permiso_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permiso
    ADD CONSTRAINT permisos_id_permiso_pk PRIMARY KEY (id);


--
-- Name: persona persona_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona
    ADD CONSTRAINT persona_pk PRIMARY KEY (id);


--
-- Name: persona persona_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona
    ADD CONSTRAINT persona_un UNIQUE (ci);


--
-- Name: presupuesto_compra_detalle presupuesto_compra_detalle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_compra_detalle
    ADD CONSTRAINT presupuesto_compra_detalle_pkey PRIMARY KEY (id);


--
-- Name: presupuesto_compra presupuesto_compra_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_compra
    ADD CONSTRAINT presupuesto_compra_pkey PRIMARY KEY (id);


--
-- Name: presupuesto_servicio_detalle presupuesto_servicio_detalle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_servicio_detalle
    ADD CONSTRAINT presupuesto_servicio_detalle_pkey PRIMARY KEY (id);


--
-- Name: presupuesto_servicio presupuesto_servicio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_servicio
    ADD CONSTRAINT presupuesto_servicio_pkey PRIMARY KEY (id);


--
-- Name: promo_descuento promo_descuento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_descuento
    ADD CONSTRAINT promo_descuento_pkey PRIMARY KEY (id);


--
-- Name: proveedor proveedores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proveedor
    ADD CONSTRAINT proveedores_pkey PRIMARY KEY (id);


--
-- Name: proveedor proveedores_prove_ruc_prove_ruc1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proveedor
    ADD CONSTRAINT proveedores_prove_ruc_prove_ruc1_key UNIQUE (ruc) INCLUDE (ruc);


--
-- Name: recepcion_detalle recepcion_detalle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recepcion_detalle
    ADD CONSTRAINT recepcion_detalle_pkey PRIMARY KEY (id);


--
-- Name: recepcion recepcion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recepcion
    ADD CONSTRAINT recepcion_pkey PRIMARY KEY (id);


--
-- Name: rol roles_id_rol_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rol
    ADD CONSTRAINT roles_id_rol_pk PRIMARY KEY (id);


--
-- Name: rol roles_nombre_rol_unk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rol
    ADD CONSTRAINT roles_nombre_rol_unk UNIQUE (nombre);


--
-- Name: servicio servicio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.servicio
    ADD CONSTRAINT servicio_pkey PRIMARY KEY (id);


--
-- Name: servicios_por_diagnostico_detalle servicios_por_diagnostico_detalle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.servicios_por_diagnostico_detalle
    ADD CONSTRAINT servicios_por_diagnostico_detalle_pkey PRIMARY KEY (id_diagnostico_detalle, id_servicio);


--
-- Name: sistema sistemas_id_sistema_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sistema
    ADD CONSTRAINT sistemas_id_sistema_pk PRIMARY KEY (id);


--
-- Name: sistema sistemas_nombre_sistema_unk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sistema
    ADD CONSTRAINT sistemas_nombre_sistema_unk UNIQUE (nombre);


--
-- Name: stock stock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock
    ADD CONSTRAINT stock_pkey PRIMARY KEY (id);


--
-- Name: sub_menu submenus_id_submenu_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_menu
    ADD CONSTRAINT submenus_id_submenu_pk PRIMARY KEY (id);


--
-- Name: sub_menu submenus_nombre_submenu_unk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_menu
    ADD CONSTRAINT submenus_nombre_submenu_unk UNIQUE (nombre);


--
-- Name: sucursal sucursales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sucursal
    ADD CONSTRAINT sucursales_pkey PRIMARY KEY (id);


--
-- Name: sucursal sucursales_suc_descri_suc_descri1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sucursal
    ADD CONSTRAINT sucursales_suc_descri_suc_descri1_key UNIQUE (descripcion) INCLUDE (descripcion);


--
-- Name: tarjeta tarjeta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tarjeta
    ADD CONSTRAINT tarjeta_pkey PRIMARY KEY (id);


--
-- Name: tarjeta tarjeta_tarjeta_descri_tarjeta_descri1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tarjeta
    ADD CONSTRAINT tarjeta_tarjeta_descri_tarjeta_descri1_key UNIQUE (descripcion) INCLUDE (descripcion);


--
-- Name: timbrado timbrado_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.timbrado
    ADD CONSTRAINT timbrado_pk PRIMARY KEY (id);


--
-- Name: tipo_articulo tipo_articulo_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_articulo
    ADD CONSTRAINT tipo_articulo_pk PRIMARY KEY (id);


--
-- Name: tipo_articulo tipo_articulo_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_articulo
    ADD CONSTRAINT tipo_articulo_un UNIQUE (descripcion);


--
-- Name: tipo_cheque tipo_cheque_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_cheque
    ADD CONSTRAINT tipo_cheque_pk PRIMARY KEY (id);


--
-- Name: tipo_cheque tipo_cheque_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_cheque
    ADD CONSTRAINT tipo_cheque_un UNIQUE (descripcion);


--
-- Name: tipo_documento tipo_documento_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_documento
    ADD CONSTRAINT tipo_documento_pk PRIMARY KEY (id);


--
-- Name: tipo_documento tipo_documento_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_documento
    ADD CONSTRAINT tipo_documento_un UNIQUE (descripcion);


--
-- Name: tipo_item tipo_item_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_item
    ADD CONSTRAINT tipo_item_pk PRIMARY KEY (id);


--
-- Name: tipo_item tipo_item_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_item
    ADD CONSTRAINT tipo_item_un UNIQUE (descripcion);


--
-- Name: tipo_problema tipo_problemas_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_problema
    ADD CONSTRAINT tipo_problemas_pk PRIMARY KEY (id);


--
-- Name: tipo_problema tipo_problemas_tipo_descri_tipo_descri1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_problema
    ADD CONSTRAINT tipo_problemas_tipo_descri_tipo_descri1_key UNIQUE (descripcion) INCLUDE (descripcion);


--
-- Name: tipo_tarjeta tipo_tarjeta_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_tarjeta
    ADD CONSTRAINT tipo_tarjeta_pk PRIMARY KEY (id);


--
-- Name: tipo_tarjeta tipo_tarjeta_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_tarjeta
    ADD CONSTRAINT tipo_tarjeta_un UNIQUE (descripcion);


--
-- Name: usuario usuarios_id_usuario_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuarios_id_usuario_pk PRIMARY KEY (id);


--
-- Name: usuario usuarios_usuario_usuario_usuario_usuario1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuarios_usuario_usuario_usuario_usuario1_key UNIQUE (usuario) INCLUDE (usuario);


--
-- Name: usuario_rol usuariosroles_id_usuario_id_rol_id_usuario1_id_rol1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario_rol
    ADD CONSTRAINT usuariosroles_id_usuario_id_rol_id_usuario1_id_rol1_key UNIQUE (id_usuario, id_rol) INCLUDE (id_usuario, id_rol);


--
-- Name: usuario_rol usuariosroles_id_usuariorol_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario_rol
    ADD CONSTRAINT usuariosroles_id_usuariorol_pk PRIMARY KEY (id);


--
-- Name: marcas_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX marcas_index ON public.marca USING btree (lower((descripcion)::text));


--
-- Name: ajuste ajuste_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ajuste
    ADD CONSTRAINT ajuste_fk FOREIGN KEY (id_estado) REFERENCES public.estado(id);


--
-- Name: apertura_cierre_caja apertura_cierre_caja_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.apertura_cierre_caja
    ADD CONSTRAINT apertura_cierre_caja_fk FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- Name: articulo articulo_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articulo
    ADD CONSTRAINT articulo_fk FOREIGN KEY (id_impuesto) REFERENCES public.impuesto(id);


--
-- Name: articulo articulo_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articulo
    ADD CONSTRAINT articulo_fk_1 FOREIGN KEY (id_marca) REFERENCES public.marca(id);


--
-- Name: articulo articulo_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articulo
    ADD CONSTRAINT articulo_fk_2 FOREIGN KEY (id_tipo_articulo) REFERENCES public.tipo_articulo(id);


--
-- Name: caja caja_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.caja
    ADD CONSTRAINT caja_fk FOREIGN KEY (id_sucursal) REFERENCES public.sucursal(id);


--
-- Name: cuenta_a_pagar cuenta_a_pagar_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cuenta_a_pagar
    ADD CONSTRAINT cuenta_a_pagar_fk FOREIGN KEY (id_pago) REFERENCES public.pago(id);


--
-- Name: deposito deposito_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deposito
    ADD CONSTRAINT deposito_fk FOREIGN KEY (id_sucursal) REFERENCES public.sucursal(id);


--
-- Name: diagnostico_detalle diagnostico_detalle_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diagnostico_detalle
    ADD CONSTRAINT diagnostico_detalle_fk FOREIGN KEY (id_servicio) REFERENCES public.servicio(id);


--
-- Name: persona empleado_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona
    ADD CONSTRAINT empleado_fk FOREIGN KEY (id_ciudad) REFERENCES public.ciudad(id);


--
-- Name: equipo equipo_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipo
    ADD CONSTRAINT equipo_fk FOREIGN KEY (id_marca) REFERENCES public.marca(id);


--
-- Name: equipo equipo_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipo
    ADD CONSTRAINT equipo_fk_2 FOREIGN KEY (id_cliente) REFERENCES public.cliente(id);


--
-- Name: factura factura_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura
    ADD CONSTRAINT factura_fk FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- Name: factura factura_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura
    ADD CONSTRAINT factura_fk_2 FOREIGN KEY (id_timbrado) REFERENCES public.timbrado(id);


--
-- Name: ajuste fk_ajuste_id_stock; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ajuste
    ADD CONSTRAINT fk_ajuste_id_stock FOREIGN KEY (id_stock) REFERENCES public.stock(id);


--
-- Name: apertura_cierre_caja fk_apertura_cierre_caja_id_caja; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.apertura_cierre_caja
    ADD CONSTRAINT fk_apertura_cierre_caja_id_caja FOREIGN KEY (id_caja) REFERENCES public.caja(id);


--
-- Name: cliente fk_cliente_id_ciudad; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT fk_cliente_id_ciudad FOREIGN KEY (id_ciudad) REFERENCES public.ciudad(id);


--
-- Name: cuenta_a_cobrar fk_cuenta_a_cobrar_id_cobro; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cuenta_a_cobrar
    ADD CONSTRAINT fk_cuenta_a_cobrar_id_cobro FOREIGN KEY (id_cobro) REFERENCES public.cobro(id);


--
-- Name: cuenta_a_cobrar fk_cuenta_a_cobrar_id_estado; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cuenta_a_cobrar
    ADD CONSTRAINT fk_cuenta_a_cobrar_id_estado FOREIGN KEY (id_estado) REFERENCES public.estado(id);


--
-- Name: cuenta_a_cobrar fk_cuenta_a_cobrar_id_factura; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cuenta_a_cobrar
    ADD CONSTRAINT fk_cuenta_a_cobrar_id_factura FOREIGN KEY (id_factura) REFERENCES public.factura(id);


--
-- Name: cuenta_a_pagar fk_cuenta_a_pagar_id_estado; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cuenta_a_pagar
    ADD CONSTRAINT fk_cuenta_a_pagar_id_estado FOREIGN KEY (id_estado) REFERENCES public.estado(id);


--
-- Name: pedido_compra_detalle fk_detalle_pedido_compra_id_articulo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_compra_detalle
    ADD CONSTRAINT fk_detalle_pedido_compra_id_articulo FOREIGN KEY (id_articulo) REFERENCES public.articulo(id);


--
-- Name: pedido_compra_detalle fk_detalle_pedido_compra_id_detalle; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_compra_detalle
    ADD CONSTRAINT fk_detalle_pedido_compra_id_detalle FOREIGN KEY (id_pedido_compra) REFERENCES public.pedido_compra(id);


--
-- Name: diagnostico_detalle fk_diagnostico_detalle_id_diagnostico; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diagnostico_detalle
    ADD CONSTRAINT fk_diagnostico_detalle_id_diagnostico FOREIGN KEY (id_diagnostico) REFERENCES public.diagnostico(id);


--
-- Name: diagnostico_detalle fk_diagnostico_detalle_id_recepcion_detalle; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diagnostico_detalle
    ADD CONSTRAINT fk_diagnostico_detalle_id_recepcion_detalle FOREIGN KEY (id_recepcion_detalle) REFERENCES public.recepcion_detalle(id);


--
-- Name: diagnostico fk_diagnostico_id_estado; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diagnostico
    ADD CONSTRAINT fk_diagnostico_id_estado FOREIGN KEY (id_estado) REFERENCES public.estado(id);


--
-- Name: diagnostico fk_diagnostico_id_recepcion; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diagnostico
    ADD CONSTRAINT fk_diagnostico_id_recepcion FOREIGN KEY (id_recepcion) REFERENCES public.recepcion(id);


--
-- Name: diagnostico fk_diagnostico_id_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diagnostico
    ADD CONSTRAINT fk_diagnostico_id_usuario FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- Name: factura_compra_detalle fk_factura_compra_detalle_id_factura_compra; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura_compra_detalle
    ADD CONSTRAINT fk_factura_compra_detalle_id_factura_compra FOREIGN KEY (id_factura_compra) REFERENCES public.factura_compra(id);


--
-- Name: factura_compra_detalle fk_factura_compra_detalle_id_orden_compra_detalle; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura_compra_detalle
    ADD CONSTRAINT fk_factura_compra_detalle_id_orden_compra_detalle FOREIGN KEY (id_orden_compra_detalle) REFERENCES public.orden_compra_detalle(id);


--
-- Name: factura_compra fk_factura_compra_id_estado; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura_compra
    ADD CONSTRAINT fk_factura_compra_id_estado FOREIGN KEY (id_estado) REFERENCES public.estado(id);


--
-- Name: factura_compra fk_factura_compra_id_libro_compra; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura_compra
    ADD CONSTRAINT fk_factura_compra_id_libro_compra FOREIGN KEY (id_libro_compra) REFERENCES public.libro_compra(id);


--
-- Name: factura_compra fk_factura_compra_id_orden_compra; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura_compra
    ADD CONSTRAINT fk_factura_compra_id_orden_compra FOREIGN KEY (id_orden_compra) REFERENCES public.orden_compra(id);


--
-- Name: factura_compra fk_factura_compra_id_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura_compra
    ADD CONSTRAINT fk_factura_compra_id_usuario FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- Name: factura_detalle fk_factura_detalle_id_factura; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura_detalle
    ADD CONSTRAINT fk_factura_detalle_id_factura FOREIGN KEY (id_factura) REFERENCES public.factura(id);


--
-- Name: factura_detalle fk_factura_detalle_id_oreden_servicio_detalle; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura_detalle
    ADD CONSTRAINT fk_factura_detalle_id_oreden_servicio_detalle FOREIGN KEY (id_oreden_servicio_detalle) REFERENCES public.orden_servicio_detalle(id);


--
-- Name: factura_detalle fk_factura_detalle_id_pedido_venta_detalle; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura_detalle
    ADD CONSTRAINT fk_factura_detalle_id_pedido_venta_detalle FOREIGN KEY (id_pedido_venta_detalle) REFERENCES public.pedido_venta_detalle(id);


--
-- Name: factura fk_factura_id_caja; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura
    ADD CONSTRAINT fk_factura_id_caja FOREIGN KEY (id_caja) REFERENCES public.caja(id);


--
-- Name: factura fk_factura_id_condicion_pago; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura
    ADD CONSTRAINT fk_factura_id_condicion_pago FOREIGN KEY (id_condicion_pago) REFERENCES public.condicion_pago(id);


--
-- Name: factura fk_factura_id_estado; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura
    ADD CONSTRAINT fk_factura_id_estado FOREIGN KEY (id_estado) REFERENCES public.estado(id);


--
-- Name: factura fk_factura_id_libro_venta; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura
    ADD CONSTRAINT fk_factura_id_libro_venta FOREIGN KEY (id_libro_venta) REFERENCES public.libro_venta(id);


--
-- Name: factura fk_factura_id_pedido_venta; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura
    ADD CONSTRAINT fk_factura_id_pedido_venta FOREIGN KEY (id_pedido_venta) REFERENCES public.pedido_venta(id);


--
-- Name: libro_compra_detalle fk_libro_compra_detalle_id_factura_compra_detalle; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.libro_compra_detalle
    ADD CONSTRAINT fk_libro_compra_detalle_id_factura_compra_detalle FOREIGN KEY (id_factura_compra_detalle) REFERENCES public.factura_compra_detalle(id);


--
-- Name: libro_compra_detalle fk_libro_compra_detalle_id_impuesto; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.libro_compra_detalle
    ADD CONSTRAINT fk_libro_compra_detalle_id_impuesto FOREIGN KEY (id_impuesto) REFERENCES public.impuesto(id);


--
-- Name: libro_compra_detalle fk_libro_compra_detalle_id_libro_compra; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.libro_compra_detalle
    ADD CONSTRAINT fk_libro_compra_detalle_id_libro_compra FOREIGN KEY (id_libro_compra) REFERENCES public.libro_compra(id);


--
-- Name: libro_venta_detalle fk_libro_venta_detalle_id_factura_detalle; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.libro_venta_detalle
    ADD CONSTRAINT fk_libro_venta_detalle_id_factura_detalle FOREIGN KEY (id_factura_detalle) REFERENCES public.factura_detalle(id);


--
-- Name: libro_venta_detalle fk_libro_venta_detalle_id_impuesto; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.libro_venta_detalle
    ADD CONSTRAINT fk_libro_venta_detalle_id_impuesto FOREIGN KEY (id_impuesto) REFERENCES public.impuesto(id);


--
-- Name: libro_venta_detalle fk_libro_venta_detalle_id_libro_venta; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.libro_venta_detalle
    ADD CONSTRAINT fk_libro_venta_detalle_id_libro_venta FOREIGN KEY (id_libro_venta) REFERENCES public.libro_venta(id);


--
-- Name: nota_credito_compra_detalle fk_nota_credito_compra_detalle_id_articulo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_credito_compra_detalle
    ADD CONSTRAINT fk_nota_credito_compra_detalle_id_articulo FOREIGN KEY (id_articulo) REFERENCES public.articulo(id);


--
-- Name: nota_credito_compra_detalle fk_nota_credito_compra_detalle_id_nota_credito_compra; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_credito_compra_detalle
    ADD CONSTRAINT fk_nota_credito_compra_detalle_id_nota_credito_compra FOREIGN KEY (id_nota_credito_compra) REFERENCES public.nota_credito_compra(id);


--
-- Name: nota_credito_compra fk_nota_credito_compra_id_estado; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_credito_compra
    ADD CONSTRAINT fk_nota_credito_compra_id_estado FOREIGN KEY (id_estado) REFERENCES public.estado(id);


--
-- Name: nota_credito_compra fk_nota_credito_compra_id_factura_compra; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_credito_compra
    ADD CONSTRAINT fk_nota_credito_compra_id_factura_compra FOREIGN KEY (id_factura_compra) REFERENCES public.factura_compra(id);


--
-- Name: nota_credito_compra fk_nota_credito_compra_id_proveedor; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_credito_compra
    ADD CONSTRAINT fk_nota_credito_compra_id_proveedor FOREIGN KEY (id_proveedor) REFERENCES public.proveedor(id);


--
-- Name: nota_debito_compra_detalle fk_nota_debito_compra_detalle_id_factura_compra_detalle; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_debito_compra_detalle
    ADD CONSTRAINT fk_nota_debito_compra_detalle_id_factura_compra_detalle FOREIGN KEY (id_factura_compra_detalle) REFERENCES public.factura_compra_detalle(id);


--
-- Name: nota_debito_compra_detalle fk_nota_debito_compra_detalle_id_nota_debito; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_debito_compra_detalle
    ADD CONSTRAINT fk_nota_debito_compra_detalle_id_nota_debito FOREIGN KEY (id_nota_debito) REFERENCES public.nota_debito_compra(id);


--
-- Name: nota_debito_compra fk_nota_debito_compra_id_cuenta_a_pagar; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_debito_compra
    ADD CONSTRAINT fk_nota_debito_compra_id_cuenta_a_pagar FOREIGN KEY (id_cuenta_a_pagar) REFERENCES public.cuenta_a_pagar(id);


--
-- Name: nota_debito_compra fk_nota_debito_compra_id_estado; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_debito_compra
    ADD CONSTRAINT fk_nota_debito_compra_id_estado FOREIGN KEY (id_estado) REFERENCES public.estado(id);


--
-- Name: nota_debito_compra fk_nota_debito_compra_id_factura_compra; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_debito_compra
    ADD CONSTRAINT fk_nota_debito_compra_id_factura_compra FOREIGN KEY (id_factura_compra) REFERENCES public.factura_compra(id);


--
-- Name: nota_remision_detalle fk_nota_remision_detalle_id_articulo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_remision_detalle
    ADD CONSTRAINT fk_nota_remision_detalle_id_articulo FOREIGN KEY (id_articulo) REFERENCES public.articulo(id);


--
-- Name: nota_remision_detalle fk_nota_remision_detalle_id_nota_remision; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_remision_detalle
    ADD CONSTRAINT fk_nota_remision_detalle_id_nota_remision FOREIGN KEY (id_nota_remision) REFERENCES public.nota_remision(id);


--
-- Name: nota_remision_detalle fk_nota_remision_detalle_id_pedido_compra_detalle; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_remision_detalle
    ADD CONSTRAINT fk_nota_remision_detalle_id_pedido_compra_detalle FOREIGN KEY (id_pedido_compra_detalle) REFERENCES public.pedido_compra_detalle(id);


--
-- Name: nota_remision fk_nota_remision_id_destino; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_remision
    ADD CONSTRAINT fk_nota_remision_id_destino FOREIGN KEY (id_destino) REFERENCES public.deposito(id);


--
-- Name: nota_remision fk_nota_remision_id_estado; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_remision
    ADD CONSTRAINT fk_nota_remision_id_estado FOREIGN KEY (id_estado) REFERENCES public.estado(id);


--
-- Name: nota_remision fk_nota_remision_id_factura_compra; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_remision
    ADD CONSTRAINT fk_nota_remision_id_factura_compra FOREIGN KEY (id_factura_compra) REFERENCES public.factura_compra(id);


--
-- Name: nota_remision fk_nota_remision_id_origen; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_remision
    ADD CONSTRAINT fk_nota_remision_id_origen FOREIGN KEY (id_origen) REFERENCES public.deposito(id);


--
-- Name: nota_remision fk_nota_remision_id_pedido_compra; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_remision
    ADD CONSTRAINT fk_nota_remision_id_pedido_compra FOREIGN KEY (id_pedido_compra) REFERENCES public.pedido_compra(id);


--
-- Name: orden_compra_detalle fk_orden_compra_detalle_id_orden_compra; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden_compra_detalle
    ADD CONSTRAINT fk_orden_compra_detalle_id_orden_compra FOREIGN KEY (id_orden_compra) REFERENCES public.orden_compra(id);


--
-- Name: orden_compra_detalle fk_orden_compra_detalle_id_presupueto_compra_detalle; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden_compra_detalle
    ADD CONSTRAINT fk_orden_compra_detalle_id_presupueto_compra_detalle FOREIGN KEY (id_presupueto_compra_detalle) REFERENCES public.presupuesto_compra_detalle(id);


--
-- Name: orden_compra fk_orden_compra_id_condicion_pago; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden_compra
    ADD CONSTRAINT fk_orden_compra_id_condicion_pago FOREIGN KEY (id_condicion_pago) REFERENCES public.condicion_pago(id);


--
-- Name: orden_compra fk_orden_compra_id_estado; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden_compra
    ADD CONSTRAINT fk_orden_compra_id_estado FOREIGN KEY (id_estado) REFERENCES public.estado(id);


--
-- Name: orden_compra fk_orden_compra_id_proveedor; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden_compra
    ADD CONSTRAINT fk_orden_compra_id_proveedor FOREIGN KEY (id_proveedor) REFERENCES public.proveedor(id);


--
-- Name: orden_compra fk_orden_compra_id_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden_compra
    ADD CONSTRAINT fk_orden_compra_id_usuario FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- Name: orden_servicio_detalle fk_orden_servicio_detalle_id_orden_servicio; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden_servicio_detalle
    ADD CONSTRAINT fk_orden_servicio_detalle_id_orden_servicio FOREIGN KEY (id_orden_servicio) REFERENCES public.orden_servicio(id);


--
-- Name: orden_servicio_detalle fk_orden_servicio_detalle_id_presupueto_servicio_detalle; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden_servicio_detalle
    ADD CONSTRAINT fk_orden_servicio_detalle_id_presupueto_servicio_detalle FOREIGN KEY (id_presupueto_servicio_detalle) REFERENCES public.presupuesto_servicio_detalle(id);


--
-- Name: orden_servicio fk_orden_servicio_id_estado; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden_servicio
    ADD CONSTRAINT fk_orden_servicio_id_estado FOREIGN KEY (id_estado) REFERENCES public.estado(id);


--
-- Name: orden_servicio fk_orden_servicio_id_presupuesto_servicio; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden_servicio
    ADD CONSTRAINT fk_orden_servicio_id_presupuesto_servicio FOREIGN KEY (id_presupuesto_servicio) REFERENCES public.presupuesto_servicio(id);


--
-- Name: orden_servicio fk_orden_servicio_id_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden_servicio
    ADD CONSTRAINT fk_orden_servicio_id_usuario FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- Name: pedido_compra fk_pedido_compra_id_deposito; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_compra
    ADD CONSTRAINT fk_pedido_compra_id_deposito FOREIGN KEY (id_deposito) REFERENCES public.deposito(id);


--
-- Name: pedido_compra fk_pedido_compra_id_estado; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_compra
    ADD CONSTRAINT fk_pedido_compra_id_estado FOREIGN KEY (id_estado) REFERENCES public.estado(id);


--
-- Name: pedido_compra fk_pedido_compra_id_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_compra
    ADD CONSTRAINT fk_pedido_compra_id_usuario FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- Name: pedido_venta_detalle fk_pedido_venta_detalle_id_articulo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_venta_detalle
    ADD CONSTRAINT fk_pedido_venta_detalle_id_articulo FOREIGN KEY (id_articulo) REFERENCES public.articulo(id);


--
-- Name: pedido_venta_detalle fk_pedido_venta_detalle_id_pedido_venta; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_venta_detalle
    ADD CONSTRAINT fk_pedido_venta_detalle_id_pedido_venta FOREIGN KEY (id_pedido_venta) REFERENCES public.pedido_venta(id);


--
-- Name: pedido_venta fk_pedido_venta_id_deposito; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_venta
    ADD CONSTRAINT fk_pedido_venta_id_deposito FOREIGN KEY (id_deposito) REFERENCES public.deposito(id);


--
-- Name: pedido_venta fk_pedido_venta_id_estado; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_venta
    ADD CONSTRAINT fk_pedido_venta_id_estado FOREIGN KEY (id_estado) REFERENCES public.estado(id);


--
-- Name: pedido_venta fk_pedido_venta_id_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_venta
    ADD CONSTRAINT fk_pedido_venta_id_usuario FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- Name: presupuesto_compra_detalle fk_presupuesto_compra_detalle_id_pedido_compra_detalle; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_compra_detalle
    ADD CONSTRAINT fk_presupuesto_compra_detalle_id_pedido_compra_detalle FOREIGN KEY (id_pedido_compra_detalle) REFERENCES public.pedido_compra_detalle(id);


--
-- Name: presupuesto_compra_detalle fk_presupuesto_compra_detalle_id_presuesto_compra; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_compra_detalle
    ADD CONSTRAINT fk_presupuesto_compra_detalle_id_presuesto_compra FOREIGN KEY (id_presuesto_compra) REFERENCES public.presupuesto_compra(id);


--
-- Name: presupuesto_compra fk_presupuesto_compra_id_estado; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_compra
    ADD CONSTRAINT fk_presupuesto_compra_id_estado FOREIGN KEY (id_estado) REFERENCES public.estado(id);


--
-- Name: presupuesto_compra fk_presupuesto_compra_id_pedido_compra; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_compra
    ADD CONSTRAINT fk_presupuesto_compra_id_pedido_compra FOREIGN KEY (id_pedido_compra) REFERENCES public.pedido_compra(id);


--
-- Name: presupuesto_compra fk_presupuesto_compra_id_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_compra
    ADD CONSTRAINT fk_presupuesto_compra_id_usuario FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- Name: presupuesto_servicio_detalle fk_presupuesto_servicio_detalle_id_diagnostico_detalle; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_servicio_detalle
    ADD CONSTRAINT fk_presupuesto_servicio_detalle_id_diagnostico_detalle FOREIGN KEY (id_diagnostico_detalle) REFERENCES public.diagnostico_detalle(id);


--
-- Name: presupuesto_servicio_detalle fk_presupuesto_servicio_detalle_id_presuesto_servicio; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_servicio_detalle
    ADD CONSTRAINT fk_presupuesto_servicio_detalle_id_presuesto_servicio FOREIGN KEY (id_presuesto_servicio) REFERENCES public.presupuesto_servicio(id);


--
-- Name: presupuesto_servicio fk_presupuesto_servicio_id_diagnostico; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_servicio
    ADD CONSTRAINT fk_presupuesto_servicio_id_diagnostico FOREIGN KEY (id_diagnostico) REFERENCES public.diagnostico(id);


--
-- Name: presupuesto_servicio fk_presupuesto_servicio_id_estado; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_servicio
    ADD CONSTRAINT fk_presupuesto_servicio_id_estado FOREIGN KEY (id_estado) REFERENCES public.estado(id);


--
-- Name: presupuesto_servicio fk_presupuesto_servicio_id_promo_descuento; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_servicio
    ADD CONSTRAINT fk_presupuesto_servicio_id_promo_descuento FOREIGN KEY (id_promo_descuento) REFERENCES public.promo_descuento(id);


--
-- Name: presupuesto_servicio fk_presupuesto_servicio_id_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_servicio
    ADD CONSTRAINT fk_presupuesto_servicio_id_usuario FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- Name: recepcion_detalle fk_recepcion_detalle_id_equipo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recepcion_detalle
    ADD CONSTRAINT fk_recepcion_detalle_id_equipo FOREIGN KEY (id_equipo) REFERENCES public.equipo(id);


--
-- Name: recepcion_detalle fk_recepcion_detalle_id_recepcion; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recepcion_detalle
    ADD CONSTRAINT fk_recepcion_detalle_id_recepcion FOREIGN KEY (id_recepcion) REFERENCES public.recepcion(id);


--
-- Name: recepcion fk_recepcion_id_estado; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recepcion
    ADD CONSTRAINT fk_recepcion_id_estado FOREIGN KEY (id_estado) REFERENCES public.estado(id);


--
-- Name: recepcion fk_recepcion_id_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recepcion
    ADD CONSTRAINT fk_recepcion_id_usuario FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- Name: servicios_por_diagnostico_detalle fk_servicios_por_diagnostico_detalle_id_diagnostico_detalle; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.servicios_por_diagnostico_detalle
    ADD CONSTRAINT fk_servicios_por_diagnostico_detalle_id_diagnostico_detalle FOREIGN KEY (id_diagnostico_detalle) REFERENCES public.diagnostico_detalle(id);


--
-- Name: servicios_por_diagnostico_detalle fk_servicios_por_diagnostico_detalle_id_servicio; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.servicios_por_diagnostico_detalle
    ADD CONSTRAINT fk_servicios_por_diagnostico_detalle_id_servicio FOREIGN KEY (id_servicio) REFERENCES public.servicio(id);


--
-- Name: stock fk_stock_id_articulo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock
    ADD CONSTRAINT fk_stock_id_articulo FOREIGN KEY (id_articulo) REFERENCES public.articulo(id);


--
-- Name: stock fk_stock_id_deposito; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock
    ADD CONSTRAINT fk_stock_id_deposito FOREIGN KEY (id_deposito) REFERENCES public.deposito(id);


--
-- Name: formulario formulario_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.formulario
    ADD CONSTRAINT formulario_fk FOREIGN KEY (id_sistema) REFERENCES public.sistema(id);


--
-- Name: formulario formulario_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.formulario
    ADD CONSTRAINT formulario_fk_1 FOREIGN KEY (id_sub_menu) REFERENCES public.sub_menu(id);


--
-- Name: nota_credito_compra nota_credito_compra_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_credito_compra
    ADD CONSTRAINT nota_credito_compra_fk FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- Name: nota_credito_compra nota_credito_compra_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_credito_compra
    ADD CONSTRAINT nota_credito_compra_fk_2 FOREIGN KEY (id_orden_compra_cancelacion) REFERENCES public.orden_compra(id);


--
-- Name: nota_remision nota_remision_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_remision
    ADD CONSTRAINT nota_remision_fk FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- Name: orden_servicio orden_servicio_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden_servicio
    ADD CONSTRAINT orden_servicio_fk FOREIGN KEY (id_factura) REFERENCES public.factura(id);


--
-- Name: pedido_venta pedido_venta_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_venta
    ADD CONSTRAINT pedido_venta_fk FOREIGN KEY (id_cliente) REFERENCES public.cliente(id);


--
-- Name: permiso permiso_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permiso
    ADD CONSTRAINT permiso_fk FOREIGN KEY (id_formulario) REFERENCES public.formulario(id);


--
-- Name: permiso permiso_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permiso
    ADD CONSTRAINT permiso_fk_1 FOREIGN KEY (id_rol) REFERENCES public.rol(id);


--
-- Name: presupuesto_compra presupuesto_compra_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_compra
    ADD CONSTRAINT presupuesto_compra_fk FOREIGN KEY (id_proveedor) REFERENCES public.proveedor(id);


--
-- Name: presupuesto_compra presupuesto_compra_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_compra
    ADD CONSTRAINT presupuesto_compra_fk_2 FOREIGN KEY (id_orden_compra) REFERENCES public.orden_compra(id);


--
-- Name: proveedor proveedor_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proveedor
    ADD CONSTRAINT proveedor_fk FOREIGN KEY (id_ciudad) REFERENCES public.ciudad(id);


--
-- Name: recepcion recepcion_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recepcion
    ADD CONSTRAINT recepcion_fk FOREIGN KEY (id_sucursal) REFERENCES public.sucursal(id);


--
-- Name: recepcion recepcion_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recepcion
    ADD CONSTRAINT recepcion_fk_2 FOREIGN KEY (id_cliente) REFERENCES public.cliente(id);


--
-- Name: servicio servicio_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.servicio
    ADD CONSTRAINT servicio_fk FOREIGN KEY (id_impuesto) REFERENCES public.impuesto(id);


--
-- Name: servicio servicio_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.servicio
    ADD CONSTRAINT servicio_fk_2 FOREIGN KEY (id_articulo) REFERENCES public.articulo(id);


--
-- Name: sucursal sucursal_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sucursal
    ADD CONSTRAINT sucursal_fk FOREIGN KEY (id_ciudad) REFERENCES public.ciudad(id);


--
-- Name: encargado sucursales_encargado_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.encargado
    ADD CONSTRAINT sucursales_encargado_fk FOREIGN KEY (id_sucursal) REFERENCES public.sucursal(id);


--
-- Name: usuario usuario_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_fk FOREIGN KEY (id_sucursal) REFERENCES public.sucursal(id);


--
-- Name: usuario_rol usuariosroles_id_rol_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario_rol
    ADD CONSTRAINT usuariosroles_id_rol_fk FOREIGN KEY (id_rol) REFERENCES public.rol(id);


--
-- Name: usuario_rol usuariosroles_id_usuario_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario_rol
    ADD CONSTRAINT usuariosroles_id_usuario_fk FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- PostgreSQL database dump complete
--

