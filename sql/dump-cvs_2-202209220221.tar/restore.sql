--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE cvs_2;
--
-- Name: cvs_2; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE cvs_2 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Spanish_Paraguay.1252';


ALTER DATABASE cvs_2 OWNER TO postgres;

\connect cvs_2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: calcular_total_presupuesto(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.calcular_total_presupuesto() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
		UPDATE presupuestos SET presu_total = (presu_total + (NEW.cant_presu * NEW.precio_presu)) WHERE presupuestos.presu_id = NEW.presu_id;
		RETURN new;
	END;
$$;


ALTER FUNCTION public.calcular_total_presupuesto() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accesorio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accesorio (
    id integer NOT NULL,
    descripcion character varying(60) NOT NULL,
    estado character varying
);


ALTER TABLE public.accesorio OWNER TO postgres;

--
-- Name: accesorios_acces_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accesorios_acces_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accesorios_acces_id_seq OWNER TO postgres;

--
-- Name: accesorios_acces_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accesorios_acces_id_seq OWNED BY public.accesorio.id;


--
-- Name: articulo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.articulo (
    id integer NOT NULL,
    descripcion character varying NOT NULL,
    precio_compra bigint NOT NULL,
    precio_venta bigint NOT NULL,
    codigo_generico character varying NOT NULL,
    id_impuesto integer NOT NULL,
    id_marca integer NOT NULL,
    id_tipo_articulo integer NOT NULL,
    estado character varying
);


ALTER TABLE public.articulo OWNER TO postgres;

--
-- Name: articulo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.articulo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.articulo_id_seq OWNER TO postgres;

--
-- Name: articulo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.articulo_id_seq OWNED BY public.articulo.id;


--
-- Name: banco; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.banco (
    id integer NOT NULL,
    descripcion character varying(200) NOT NULL,
    estado character varying
);


ALTER TABLE public.banco OWNER TO postgres;

--
-- Name: banco_banco_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.banco_banco_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.banco_banco_id_seq OWNER TO postgres;

--
-- Name: banco_banco_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.banco_banco_id_seq OWNED BY public.banco.id;


--
-- Name: banco_cheque; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.banco_cheque (
    id integer NOT NULL,
    descripcion character varying,
    estado character varying
);


ALTER TABLE public.banco_cheque OWNER TO postgres;

--
-- Name: banco_cheque_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.banco_cheque_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.banco_cheque_id_seq OWNER TO postgres;

--
-- Name: banco_cheque_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.banco_cheque_id_seq OWNED BY public.banco_cheque.id;


--
-- Name: caja; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.caja (
    id integer NOT NULL,
    descripcion character varying(90) NOT NULL,
    numero integer NOT NULL,
    estado character varying
);


ALTER TABLE public.caja OWNER TO postgres;

--
-- Name: caja_caja_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.caja_caja_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.caja_caja_id_seq OWNER TO postgres;

--
-- Name: caja_caja_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.caja_caja_id_seq OWNED BY public.caja.id;


--
-- Name: cargo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cargo (
    id integer NOT NULL,
    descripcion character varying,
    estado character varying
);


ALTER TABLE public.cargo OWNER TO postgres;

--
-- Name: cargo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cargo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cargo_id_seq OWNER TO postgres;

--
-- Name: cargo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cargo_id_seq OWNED BY public.cargo.id;


--
-- Name: ciudad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ciudad (
    id integer NOT NULL,
    descripcion character varying,
    estado character varying
);


ALTER TABLE public.ciudad OWNER TO postgres;

--
-- Name: ciudad_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ciudad_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ciudad_id_seq OWNER TO postgres;

--
-- Name: ciudad_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ciudad_id_seq OWNED BY public.ciudad.id;


--
-- Name: cliente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cliente (
    id integer NOT NULL,
    nombre character varying(200) NOT NULL,
    apellido character varying(200) NOT NULL,
    ci character varying(200) NOT NULL,
    fecha_nacimiento date NOT NULL,
    direccion character varying(80) NOT NULL,
    telefono character varying(20) NOT NULL,
    email character varying(50) NOT NULL,
    estado character varying
);


ALTER TABLE public.cliente OWNER TO postgres;

--
-- Name: clientes_cli_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.clientes_cli_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.clientes_cli_id_seq OWNER TO postgres;

--
-- Name: clientes_cli_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.clientes_cli_id_seq OWNED BY public.cliente.id;


--
-- Name: condicion_pago; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.condicion_pago (
    id integer NOT NULL,
    descripcion character varying,
    estado character varying
);


ALTER TABLE public.condicion_pago OWNER TO postgres;

--
-- Name: condicion_pago_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.condicion_pago_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.condicion_pago_id_seq OWNER TO postgres;

--
-- Name: condicion_pago_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.condicion_pago_id_seq OWNED BY public.condicion_pago.id;


--
-- Name: deposito_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.deposito_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.deposito_id_seq OWNER TO postgres;

--
-- Name: deposito; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deposito (
    id integer DEFAULT nextval('public.deposito_id_seq'::regclass) NOT NULL,
    descripcion character varying,
    id_sucursal integer,
    estado character varying
);


ALTER TABLE public.deposito OWNER TO postgres;

--
-- Name: detalle_pedido_compra; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.detalle_pedido_compra (
    id integer NOT NULL,
    cantidad integer,
    estado character varying(255),
    id_articulo integer
);


ALTER TABLE public.detalle_pedido_compra OWNER TO postgres;

--
-- Name: pedido_compra_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pedido_compra_detalle (
    id integer NOT NULL,
    cantidad integer,
    estado character varying(255),
    id_articulo integer,
    id_pedido_compra integer
);


ALTER TABLE public.pedido_compra_detalle OWNER TO postgres;

--
-- Name: detalle_pedido_compra_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.detalle_pedido_compra_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.detalle_pedido_compra_id_seq OWNER TO postgres;

--
-- Name: detalle_pedido_compra_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.detalle_pedido_compra_id_seq OWNED BY public.pedido_compra_detalle.id;


--
-- Name: detalle_pedido_compra_id_seq1; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.detalle_pedido_compra_id_seq1
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.detalle_pedido_compra_id_seq1 OWNER TO postgres;

--
-- Name: detalle_pedido_compra_id_seq1; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.detalle_pedido_compra_id_seq1 OWNED BY public.detalle_pedido_compra.id;


--
-- Name: diagnostico; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.diagnostico (
    id integer NOT NULL,
    id_recepcion integer NOT NULL,
    id_usuario integer NOT NULL,
    descripcion character varying(60) NOT NULL,
    fecha date NOT NULL,
    estado character varying(60) NOT NULL
);


ALTER TABLE public.diagnostico OWNER TO postgres;

--
-- Name: diagnostico_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.diagnostico_detalle (
    id_tipo_problema integer NOT NULL,
    id_diagnostico integer NOT NULL,
    observacion character varying(60) NOT NULL,
    estado character varying
);


ALTER TABLE public.diagnostico_detalle OWNER TO postgres;

--
-- Name: diagnostico_diagno_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.diagnostico_diagno_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.diagnostico_diagno_id_seq OWNER TO postgres;

--
-- Name: diagnostico_diagno_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.diagnostico_diagno_id_seq OWNED BY public.diagnostico.id;


--
-- Name: persona; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.persona (
    id integer NOT NULL,
    nombre character varying NOT NULL,
    apellido character varying NOT NULL,
    ci character varying NOT NULL,
    telefono character varying NOT NULL,
    direccion character varying NOT NULL,
    id_ciudad integer NOT NULL,
    estado character varying
);


ALTER TABLE public.persona OWNER TO postgres;

--
-- Name: empleado_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.empleado_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.empleado_id_seq OWNER TO postgres;

--
-- Name: empleado_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.empleado_id_seq OWNED BY public.persona.id;


--
-- Name: empresa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.empresa (
    id integer NOT NULL,
    telefono character varying(80) NOT NULL,
    direccion character varying(150) NOT NULL,
    nombre character varying(70) NOT NULL,
    ruc character varying(20) NOT NULL,
    estado character varying
);


ALTER TABLE public.empresa OWNER TO postgres;

--
-- Name: empresa_empre_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.empresa_empre_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.empresa_empre_id_seq OWNER TO postgres;

--
-- Name: empresa_empre_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.empresa_empre_id_seq OWNED BY public.empresa.id;


--
-- Name: encargado; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.encargado (
    id integer NOT NULL,
    id_sucursal integer NOT NULL,
    nombre character varying(60) NOT NULL,
    apellido character varying(60) NOT NULL,
    direccion character varying(60) NOT NULL,
    telefono character varying(60) NOT NULL,
    email character varying(60) NOT NULL
);


ALTER TABLE public.encargado OWNER TO postgres;

--
-- Name: encargado_enca_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.encargado_enca_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.encargado_enca_id_seq OWNER TO postgres;

--
-- Name: encargado_enca_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.encargado_enca_id_seq OWNED BY public.encargado.id;


--
-- Name: entidad_emisora; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.entidad_emisora (
    id integer NOT NULL,
    descripcion character varying,
    estado character varying
);


ALTER TABLE public.entidad_emisora OWNER TO postgres;

--
-- Name: entidad_emisora_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.entidad_emisora_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.entidad_emisora_id_seq OWNER TO postgres;

--
-- Name: entidad_emisora_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.entidad_emisora_id_seq OWNED BY public.entidad_emisora.id;


--
-- Name: equipo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.equipo (
    id integer NOT NULL,
    serie character varying NOT NULL,
    descripcion character varying NOT NULL,
    modelo character varying(60) NOT NULL,
    id_marca integer NOT NULL,
    estado character varying
);


ALTER TABLE public.equipo OWNER TO postgres;

--
-- Name: equipo_accesorio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.equipo_accesorio (
    id integer NOT NULL,
    id_equipo integer,
    id_accesorio integer,
    cantidad integer NOT NULL,
    observacion character varying(90) NOT NULL,
    estado character varying
);


ALTER TABLE public.equipo_accesorio OWNER TO postgres;

--
-- Name: equipoaccesorio_id_equipoaccesorio_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.equipoaccesorio_id_equipoaccesorio_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.equipoaccesorio_id_equipoaccesorio_seq OWNER TO postgres;

--
-- Name: equipoaccesorio_id_equipoaccesorio_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.equipoaccesorio_id_equipoaccesorio_seq OWNED BY public.equipo_accesorio.id;


--
-- Name: equipos_equi_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.equipos_equi_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.equipos_equi_id_seq OWNER TO postgres;

--
-- Name: equipos_equi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.equipos_equi_id_seq OWNED BY public.equipo.id;


--
-- Name: estado; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estado (
    id integer NOT NULL,
    descripcion character varying,
    estado character varying
);


ALTER TABLE public.estado OWNER TO postgres;

--
-- Name: estado_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.estado_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.estado_id_seq OWNER TO postgres;

--
-- Name: estado_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.estado_id_seq OWNED BY public.estado.id;


--
-- Name: forma_cobro; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.forma_cobro (
    id integer NOT NULL,
    descripcion character varying(40) NOT NULL,
    estado character varying
);


ALTER TABLE public.forma_cobro OWNER TO postgres;

--
-- Name: forma_cobro_form_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.forma_cobro_form_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.forma_cobro_form_id_seq OWNER TO postgres;

--
-- Name: forma_cobro_form_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.forma_cobro_form_id_seq OWNED BY public.forma_cobro.id;


--
-- Name: formulario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.formulario (
    id integer NOT NULL,
    nombre character varying,
    url character varying,
    id_sistema integer,
    id_sub_menu integer,
    id_usuario_auditoria integer,
    estado character varying
);


ALTER TABLE public.formulario OWNER TO postgres;

--
-- Name: formularios_id_formulario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.formularios_id_formulario_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.formularios_id_formulario_seq OWNER TO postgres;

--
-- Name: formularios_id_formulario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.formularios_id_formulario_seq OWNED BY public.formulario.id;


--
-- Name: impuesto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.impuesto (
    id integer NOT NULL,
    descripcion character varying,
    estado character varying
);


ALTER TABLE public.impuesto OWNER TO postgres;

--
-- Name: impuesto_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.impuesto_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.impuesto_id_seq OWNER TO postgres;

--
-- Name: impuesto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.impuesto_id_seq OWNED BY public.impuesto.id;


--
-- Name: item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item (
    id integer NOT NULL,
    descripcion character varying(200) NOT NULL,
    precio integer NOT NULL,
    stock integer NOT NULL,
    id_marca integer NOT NULL,
    estado character varying
);


ALTER TABLE public.item OWNER TO postgres;

--
-- Name: items_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.items_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.items_item_id_seq OWNER TO postgres;

--
-- Name: items_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.items_item_id_seq OWNED BY public.item.id;


--
-- Name: marca; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marca (
    id integer NOT NULL,
    descripcion character varying(60) NOT NULL,
    estado character varying
);


ALTER TABLE public.marca OWNER TO postgres;

--
-- Name: marcas_mar_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.marcas_mar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.marcas_mar_id_seq OWNER TO postgres;

--
-- Name: marcas_mar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.marcas_mar_id_seq OWNED BY public.marca.id;


--
-- Name: motivo_ajuste; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.motivo_ajuste (
    id integer NOT NULL,
    descripcion character varying(100) NOT NULL,
    estado character varying
);


ALTER TABLE public.motivo_ajuste OWNER TO postgres;

--
-- Name: motivo_ajuste_maju_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.motivo_ajuste_maju_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.motivo_ajuste_maju_id_seq OWNER TO postgres;

--
-- Name: motivo_ajuste_maju_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.motivo_ajuste_maju_id_seq OWNED BY public.motivo_ajuste.id;


--
-- Name: orden_trabajo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orden_trabajo (
    id integer NOT NULL,
    fecha_ingreso date NOT NULL,
    fecha_limite date NOT NULL,
    id_presupuesto integer NOT NULL,
    estado character varying(60) NOT NULL,
    id_usuario integer NOT NULL
);


ALTER TABLE public.orden_trabajo OWNER TO postgres;

--
-- Name: orden_trabajo_orden_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orden_trabajo_orden_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orden_trabajo_orden_id_seq OWNER TO postgres;

--
-- Name: orden_trabajo_orden_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orden_trabajo_orden_id_seq OWNED BY public.orden_trabajo.id;


--
-- Name: pedido_compra; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pedido_compra (
    id integer NOT NULL,
    estado character varying(255),
    fecha timestamp without time zone,
    id_deposito integer,
    id_estado integer,
    id_usuario integer,
    observacion character varying
);


ALTER TABLE public.pedido_compra OWNER TO postgres;

--
-- Name: pedido_compra_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pedido_compra_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pedido_compra_id_seq OWNER TO postgres;

--
-- Name: pedido_compra_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pedido_compra_id_seq OWNED BY public.pedido_compra.id;


--
-- Name: permiso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.permiso (
    id integer NOT NULL,
    id_rol integer,
    id_formulario integer,
    agregar boolean,
    modificar boolean,
    eliminar boolean,
    consultar boolean,
    listar boolean,
    informe boolean,
    exportar boolean,
    id_usuario_auditoria integer,
    estado character varying,
    reactivar boolean
);


ALTER TABLE public.permiso OWNER TO postgres;

--
-- Name: permisos_id_permiso_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.permisos_id_permiso_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permisos_id_permiso_seq OWNER TO postgres;

--
-- Name: permisos_id_permiso_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.permisos_id_permiso_seq OWNED BY public.permiso.id;


--
-- Name: presupuesto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.presupuesto (
    id integer NOT NULL,
    id_usuario integer NOT NULL,
    id_diagnostico integer NOT NULL,
    fecha date NOT NULL,
    estado character varying NOT NULL,
    total integer
);


ALTER TABLE public.presupuesto OWNER TO postgres;

--
-- Name: presupuesto_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.presupuesto_detalle (
    id_presupuesto integer NOT NULL,
    id_item integer NOT NULL,
    cantidad integer NOT NULL,
    precio integer NOT NULL,
    id integer NOT NULL,
    estado character varying
);


ALTER TABLE public.presupuesto_detalle OWNER TO postgres;

--
-- Name: presupuesto_detalle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.presupuesto_detalle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.presupuesto_detalle_id_seq OWNER TO postgres;

--
-- Name: presupuesto_detalle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.presupuesto_detalle_id_seq OWNED BY public.presupuesto_detalle.id;


--
-- Name: presupuestos_presu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.presupuestos_presu_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.presupuestos_presu_id_seq OWNER TO postgres;

--
-- Name: presupuestos_presu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.presupuestos_presu_id_seq OWNED BY public.presupuesto.id;


--
-- Name: proveedor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.proveedor (
    id integer NOT NULL,
    razon_social character varying(50) NOT NULL,
    ruc character varying(60) NOT NULL,
    telefono character varying(60) NOT NULL,
    correo character varying(60) NOT NULL,
    direccion character varying(60) NOT NULL,
    id_ciudad integer NOT NULL,
    estado character varying
);


ALTER TABLE public.proveedor OWNER TO postgres;

--
-- Name: proveedor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.proveedor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.proveedor_id_seq OWNER TO postgres;

--
-- Name: proveedor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.proveedor_id_seq OWNED BY public.proveedor.id;


--
-- Name: proveedores_prove_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.proveedores_prove_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.proveedores_prove_id_seq OWNER TO postgres;

--
-- Name: proveedores_prove_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.proveedores_prove_id_seq OWNED BY public.proveedor.id;


--
-- Name: recepcion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recepcion (
    id integer NOT NULL,
    id_usuario integer,
    id_equipo integer NOT NULL,
    defecto character varying(100) NOT NULL,
    fecha date NOT NULL,
    estado character varying(30) NOT NULL
);


ALTER TABLE public.recepcion OWNER TO postgres;

--
-- Name: recepcion_recep_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recepcion_recep_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recepcion_recep_id_seq OWNER TO postgres;

--
-- Name: recepcion_recep_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recepcion_recep_id_seq OWNED BY public.recepcion.id;


--
-- Name: rol; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rol (
    id integer NOT NULL,
    nombre character varying,
    id_usuario_auditoria integer,
    estado character varying
);


ALTER TABLE public.rol OWNER TO postgres;

--
-- Name: roles_id_rol_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_rol_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_rol_seq OWNER TO postgres;

--
-- Name: roles_id_rol_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_rol_seq OWNED BY public.rol.id;


--
-- Name: servicio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.servicio (
    id integer NOT NULL,
    tipo character varying(60) NOT NULL,
    id_orden_trabajo integer NOT NULL,
    fecha date NOT NULL,
    estado character varying(60) NOT NULL,
    id_usuario integer NOT NULL,
    observacion character varying(60) NOT NULL
);


ALTER TABLE public.servicio OWNER TO postgres;

--
-- Name: servicio_servi_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.servicio_servi_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.servicio_servi_id_seq OWNER TO postgres;

--
-- Name: servicio_servi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.servicio_servi_id_seq OWNED BY public.servicio.id;


--
-- Name: sistema; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sistema (
    id integer NOT NULL,
    nombre character varying,
    id_usuario_auditoria integer,
    estado character varying
);


ALTER TABLE public.sistema OWNER TO postgres;

--
-- Name: sistemas_id_sistema_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sistemas_id_sistema_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sistemas_id_sistema_seq OWNER TO postgres;

--
-- Name: sistemas_id_sistema_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sistemas_id_sistema_seq OWNED BY public.sistema.id;


--
-- Name: sub_menu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sub_menu (
    id integer NOT NULL,
    nombre character varying,
    id_usuario_auditoria integer,
    estado character varying
);


ALTER TABLE public.sub_menu OWNER TO postgres;

--
-- Name: submenus_id_submenu_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.submenus_id_submenu_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.submenus_id_submenu_seq OWNER TO postgres;

--
-- Name: submenus_id_submenu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.submenus_id_submenu_seq OWNED BY public.sub_menu.id;


--
-- Name: sucursal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sucursal (
    id integer NOT NULL,
    descripcion character varying(250) NOT NULL,
    telefono character varying(20) NOT NULL,
    direccion character varying(200) NOT NULL,
    estado character varying,
    id_ciudad integer
);


ALTER TABLE public.sucursal OWNER TO postgres;

--
-- Name: sucursales_suc_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sucursales_suc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sucursales_suc_id_seq OWNER TO postgres;

--
-- Name: sucursales_suc_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sucursales_suc_id_seq OWNED BY public.sucursal.id;


--
-- Name: tarjeta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tarjeta (
    id integer NOT NULL,
    descripcion character varying(50) NOT NULL,
    estado character varying
);


ALTER TABLE public.tarjeta OWNER TO postgres;

--
-- Name: tarjeta_tarjeta_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tarjeta_tarjeta_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tarjeta_tarjeta_id_seq OWNER TO postgres;

--
-- Name: tarjeta_tarjeta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tarjeta_tarjeta_id_seq OWNED BY public.tarjeta.id;


--
-- Name: timbrado; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.timbrado (
    id integer NOT NULL,
    id_caja character varying(60),
    numero integer NOT NULL,
    tipo character varying(60),
    fecha_inicio date,
    fecha_fin date,
    inicio integer,
    fin integer,
    actual integer,
    estado character varying(60) DEFAULT 'Activo'::character varying
);


ALTER TABLE public.timbrado OWNER TO postgres;

--
-- Name: timbrado_tim_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.timbrado_tim_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.timbrado_tim_id_seq OWNER TO postgres;

--
-- Name: timbrado_tim_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.timbrado_tim_id_seq OWNED BY public.timbrado.id;


--
-- Name: tipo_articulo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_articulo (
    id integer NOT NULL,
    descripcion character varying NOT NULL,
    estado character varying
);


ALTER TABLE public.tipo_articulo OWNER TO postgres;

--
-- Name: tipo_articulo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_articulo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_articulo_id_seq OWNER TO postgres;

--
-- Name: tipo_articulo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_articulo_id_seq OWNED BY public.tipo_articulo.id;


--
-- Name: tipo_cheque; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_cheque (
    id integer NOT NULL,
    descripcion character varying,
    estado character varying
);


ALTER TABLE public.tipo_cheque OWNER TO postgres;

--
-- Name: tipo_cheque_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_cheque_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_cheque_id_seq OWNER TO postgres;

--
-- Name: tipo_cheque_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_cheque_id_seq OWNED BY public.tipo_cheque.id;


--
-- Name: tipo_documento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_documento (
    id integer NOT NULL,
    descripcion character varying,
    estado character varying
);


ALTER TABLE public.tipo_documento OWNER TO postgres;

--
-- Name: tipo_documento_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_documento_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_documento_id_seq OWNER TO postgres;

--
-- Name: tipo_documento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_documento_id_seq OWNED BY public.tipo_documento.id;


--
-- Name: tipo_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_item (
    id integer NOT NULL,
    descripcion character varying NOT NULL,
    estado character varying
);


ALTER TABLE public.tipo_item OWNER TO postgres;

--
-- Name: tipo_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_item_id_seq OWNER TO postgres;

--
-- Name: tipo_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_item_id_seq OWNED BY public.tipo_item.id;


--
-- Name: tipo_problema; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_problema (
    id integer NOT NULL,
    descripcion character varying(80) NOT NULL,
    estado character varying
);


ALTER TABLE public.tipo_problema OWNER TO postgres;

--
-- Name: tipo_problemas_tip_proble_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_problemas_tip_proble_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_problemas_tip_proble_id_seq OWNER TO postgres;

--
-- Name: tipo_problemas_tip_proble_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_problemas_tip_proble_id_seq OWNED BY public.tipo_problema.id;


--
-- Name: tipo_tarjeta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_tarjeta (
    id integer NOT NULL,
    descripcion character varying,
    estado character varying
);


ALTER TABLE public.tipo_tarjeta OWNER TO postgres;

--
-- Name: tipo_tarjeta_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_tarjeta_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_tarjeta_id_seq OWNER TO postgres;

--
-- Name: tipo_tarjeta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_tarjeta_id_seq OWNED BY public.tipo_tarjeta.id;


--
-- Name: usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuario (
    id integer NOT NULL,
    nombre character varying,
    usuario character varying,
    clave character varying,
    imagen character varying,
    id_usuario_auditoria integer,
    estado character varying,
    id_sucursal integer
);


ALTER TABLE public.usuario OWNER TO postgres;

--
-- Name: usuario_rol; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuario_rol (
    id integer NOT NULL,
    id_usuario integer,
    id_rol integer,
    id_usuario_auditoria integer,
    estado character varying
);


ALTER TABLE public.usuario_rol OWNER TO postgres;

--
-- Name: usuarios_id_usuario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuarios_id_usuario_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuarios_id_usuario_seq OWNER TO postgres;

--
-- Name: usuarios_id_usuario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuarios_id_usuario_seq OWNED BY public.usuario.id;


--
-- Name: usuariosroles_id_usuariorol_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuariosroles_id_usuariorol_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuariosroles_id_usuariorol_seq OWNER TO postgres;

--
-- Name: usuariosroles_id_usuariorol_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuariosroles_id_usuariorol_seq OWNED BY public.usuario_rol.id;


--
-- Name: accesorio id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accesorio ALTER COLUMN id SET DEFAULT nextval('public.accesorios_acces_id_seq'::regclass);


--
-- Name: articulo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articulo ALTER COLUMN id SET DEFAULT nextval('public.articulo_id_seq'::regclass);


--
-- Name: banco id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banco ALTER COLUMN id SET DEFAULT nextval('public.banco_banco_id_seq'::regclass);


--
-- Name: banco_cheque id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banco_cheque ALTER COLUMN id SET DEFAULT nextval('public.banco_cheque_id_seq'::regclass);


--
-- Name: caja id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.caja ALTER COLUMN id SET DEFAULT nextval('public.caja_caja_id_seq'::regclass);


--
-- Name: cargo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cargo ALTER COLUMN id SET DEFAULT nextval('public.cargo_id_seq'::regclass);


--
-- Name: ciudad id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ciudad ALTER COLUMN id SET DEFAULT nextval('public.ciudad_id_seq'::regclass);


--
-- Name: cliente id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente ALTER COLUMN id SET DEFAULT nextval('public.clientes_cli_id_seq'::regclass);


--
-- Name: condicion_pago id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.condicion_pago ALTER COLUMN id SET DEFAULT nextval('public.condicion_pago_id_seq'::regclass);


--
-- Name: detalle_pedido_compra id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalle_pedido_compra ALTER COLUMN id SET DEFAULT nextval('public.detalle_pedido_compra_id_seq1'::regclass);


--
-- Name: diagnostico id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diagnostico ALTER COLUMN id SET DEFAULT nextval('public.diagnostico_diagno_id_seq'::regclass);


--
-- Name: empresa id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empresa ALTER COLUMN id SET DEFAULT nextval('public.empresa_empre_id_seq'::regclass);


--
-- Name: encargado id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.encargado ALTER COLUMN id SET DEFAULT nextval('public.encargado_enca_id_seq'::regclass);


--
-- Name: entidad_emisora id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entidad_emisora ALTER COLUMN id SET DEFAULT nextval('public.entidad_emisora_id_seq'::regclass);


--
-- Name: equipo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipo ALTER COLUMN id SET DEFAULT nextval('public.equipos_equi_id_seq'::regclass);


--
-- Name: equipo_accesorio id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipo_accesorio ALTER COLUMN id SET DEFAULT nextval('public.equipoaccesorio_id_equipoaccesorio_seq'::regclass);


--
-- Name: estado id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado ALTER COLUMN id SET DEFAULT nextval('public.estado_id_seq'::regclass);


--
-- Name: forma_cobro id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forma_cobro ALTER COLUMN id SET DEFAULT nextval('public.forma_cobro_form_id_seq'::regclass);


--
-- Name: formulario id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.formulario ALTER COLUMN id SET DEFAULT nextval('public.formularios_id_formulario_seq'::regclass);


--
-- Name: impuesto id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.impuesto ALTER COLUMN id SET DEFAULT nextval('public.impuesto_id_seq'::regclass);


--
-- Name: item id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item ALTER COLUMN id SET DEFAULT nextval('public.items_item_id_seq'::regclass);


--
-- Name: marca id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marca ALTER COLUMN id SET DEFAULT nextval('public.marcas_mar_id_seq'::regclass);


--
-- Name: motivo_ajuste id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.motivo_ajuste ALTER COLUMN id SET DEFAULT nextval('public.motivo_ajuste_maju_id_seq'::regclass);


--
-- Name: orden_trabajo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden_trabajo ALTER COLUMN id SET DEFAULT nextval('public.orden_trabajo_orden_id_seq'::regclass);


--
-- Name: pedido_compra id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_compra ALTER COLUMN id SET DEFAULT nextval('public.pedido_compra_id_seq'::regclass);


--
-- Name: pedido_compra_detalle id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_compra_detalle ALTER COLUMN id SET DEFAULT nextval('public.detalle_pedido_compra_id_seq'::regclass);


--
-- Name: permiso id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permiso ALTER COLUMN id SET DEFAULT nextval('public.permisos_id_permiso_seq'::regclass);


--
-- Name: persona id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona ALTER COLUMN id SET DEFAULT nextval('public.empleado_id_seq'::regclass);


--
-- Name: presupuesto id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto ALTER COLUMN id SET DEFAULT nextval('public.presupuestos_presu_id_seq'::regclass);


--
-- Name: presupuesto_detalle id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_detalle ALTER COLUMN id SET DEFAULT nextval('public.presupuesto_detalle_id_seq'::regclass);


--
-- Name: proveedor id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proveedor ALTER COLUMN id SET DEFAULT nextval('public.proveedores_prove_id_seq'::regclass);


--
-- Name: recepcion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recepcion ALTER COLUMN id SET DEFAULT nextval('public.recepcion_recep_id_seq'::regclass);


--
-- Name: rol id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rol ALTER COLUMN id SET DEFAULT nextval('public.roles_id_rol_seq'::regclass);


--
-- Name: servicio id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.servicio ALTER COLUMN id SET DEFAULT nextval('public.servicio_servi_id_seq'::regclass);


--
-- Name: sistema id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sistema ALTER COLUMN id SET DEFAULT nextval('public.sistemas_id_sistema_seq'::regclass);


--
-- Name: sub_menu id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_menu ALTER COLUMN id SET DEFAULT nextval('public.submenus_id_submenu_seq'::regclass);


--
-- Name: sucursal id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sucursal ALTER COLUMN id SET DEFAULT nextval('public.sucursales_suc_id_seq'::regclass);


--
-- Name: tarjeta id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tarjeta ALTER COLUMN id SET DEFAULT nextval('public.tarjeta_tarjeta_id_seq'::regclass);


--
-- Name: timbrado id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.timbrado ALTER COLUMN id SET DEFAULT nextval('public.timbrado_tim_id_seq'::regclass);


--
-- Name: tipo_articulo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_articulo ALTER COLUMN id SET DEFAULT nextval('public.tipo_articulo_id_seq'::regclass);


--
-- Name: tipo_cheque id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_cheque ALTER COLUMN id SET DEFAULT nextval('public.tipo_cheque_id_seq'::regclass);


--
-- Name: tipo_documento id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_documento ALTER COLUMN id SET DEFAULT nextval('public.tipo_documento_id_seq'::regclass);


--
-- Name: tipo_item id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_item ALTER COLUMN id SET DEFAULT nextval('public.tipo_item_id_seq'::regclass);


--
-- Name: tipo_problema id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_problema ALTER COLUMN id SET DEFAULT nextval('public.tipo_problemas_tip_proble_id_seq'::regclass);


--
-- Name: tipo_tarjeta id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_tarjeta ALTER COLUMN id SET DEFAULT nextval('public.tipo_tarjeta_id_seq'::regclass);


--
-- Name: usuario id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_usuario_seq'::regclass);


--
-- Name: usuario_rol id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario_rol ALTER COLUMN id SET DEFAULT nextval('public.usuariosroles_id_usuariorol_seq'::regclass);


--
-- Data for Name: accesorio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accesorio (id, descripcion, estado) FROM stdin;
\.
COPY public.accesorio (id, descripcion, estado) FROM '$$PATH$$/3802.dat';

--
-- Data for Name: articulo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.articulo (id, descripcion, precio_compra, precio_venta, codigo_generico, id_impuesto, id_marca, id_tipo_articulo, estado) FROM stdin;
\.
COPY public.articulo (id, descripcion, precio_compra, precio_venta, codigo_generico, id_impuesto, id_marca, id_tipo_articulo, estado) FROM '$$PATH$$/3804.dat';

--
-- Data for Name: banco; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.banco (id, descripcion, estado) FROM stdin;
\.
COPY public.banco (id, descripcion, estado) FROM '$$PATH$$/3806.dat';

--
-- Data for Name: banco_cheque; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.banco_cheque (id, descripcion, estado) FROM stdin;
\.
COPY public.banco_cheque (id, descripcion, estado) FROM '$$PATH$$/3808.dat';

--
-- Data for Name: caja; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.caja (id, descripcion, numero, estado) FROM stdin;
\.
COPY public.caja (id, descripcion, numero, estado) FROM '$$PATH$$/3810.dat';

--
-- Data for Name: cargo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cargo (id, descripcion, estado) FROM stdin;
\.
COPY public.cargo (id, descripcion, estado) FROM '$$PATH$$/3812.dat';

--
-- Data for Name: ciudad; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ciudad (id, descripcion, estado) FROM stdin;
\.
COPY public.ciudad (id, descripcion, estado) FROM '$$PATH$$/3814.dat';

--
-- Data for Name: cliente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cliente (id, nombre, apellido, ci, fecha_nacimiento, direccion, telefono, email, estado) FROM stdin;
\.
COPY public.cliente (id, nombre, apellido, ci, fecha_nacimiento, direccion, telefono, email, estado) FROM '$$PATH$$/3816.dat';

--
-- Data for Name: condicion_pago; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.condicion_pago (id, descripcion, estado) FROM stdin;
\.
COPY public.condicion_pago (id, descripcion, estado) FROM '$$PATH$$/3818.dat';

--
-- Data for Name: deposito; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.deposito (id, descripcion, id_sucursal, estado) FROM stdin;
\.
COPY public.deposito (id, descripcion, id_sucursal, estado) FROM '$$PATH$$/3820.dat';

--
-- Data for Name: detalle_pedido_compra; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.detalle_pedido_compra (id, cantidad, estado, id_articulo) FROM stdin;
\.
COPY public.detalle_pedido_compra (id, cantidad, estado, id_articulo) FROM '$$PATH$$/3899.dat';

--
-- Data for Name: diagnostico; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.diagnostico (id, id_recepcion, id_usuario, descripcion, fecha, estado) FROM stdin;
\.
COPY public.diagnostico (id, id_recepcion, id_usuario, descripcion, fecha, estado) FROM '$$PATH$$/3821.dat';

--
-- Data for Name: diagnostico_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.diagnostico_detalle (id_tipo_problema, id_diagnostico, observacion, estado) FROM stdin;
\.
COPY public.diagnostico_detalle (id_tipo_problema, id_diagnostico, observacion, estado) FROM '$$PATH$$/3822.dat';

--
-- Data for Name: empresa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.empresa (id, telefono, direccion, nombre, ruc, estado) FROM stdin;
\.
COPY public.empresa (id, telefono, direccion, nombre, ruc, estado) FROM '$$PATH$$/3826.dat';

--
-- Data for Name: encargado; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.encargado (id, id_sucursal, nombre, apellido, direccion, telefono, email) FROM stdin;
\.
COPY public.encargado (id, id_sucursal, nombre, apellido, direccion, telefono, email) FROM '$$PATH$$/3828.dat';

--
-- Data for Name: entidad_emisora; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.entidad_emisora (id, descripcion, estado) FROM stdin;
\.
COPY public.entidad_emisora (id, descripcion, estado) FROM '$$PATH$$/3830.dat';

--
-- Data for Name: equipo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.equipo (id, serie, descripcion, modelo, id_marca, estado) FROM stdin;
\.
COPY public.equipo (id, serie, descripcion, modelo, id_marca, estado) FROM '$$PATH$$/3832.dat';

--
-- Data for Name: equipo_accesorio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.equipo_accesorio (id, id_equipo, id_accesorio, cantidad, observacion, estado) FROM stdin;
\.
COPY public.equipo_accesorio (id, id_equipo, id_accesorio, cantidad, observacion, estado) FROM '$$PATH$$/3833.dat';

--
-- Data for Name: estado; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.estado (id, descripcion, estado) FROM stdin;
\.
COPY public.estado (id, descripcion, estado) FROM '$$PATH$$/3836.dat';

--
-- Data for Name: forma_cobro; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.forma_cobro (id, descripcion, estado) FROM stdin;
\.
COPY public.forma_cobro (id, descripcion, estado) FROM '$$PATH$$/3838.dat';

--
-- Data for Name: formulario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.formulario (id, nombre, url, id_sistema, id_sub_menu, id_usuario_auditoria, estado) FROM stdin;
\.
COPY public.formulario (id, nombre, url, id_sistema, id_sub_menu, id_usuario_auditoria, estado) FROM '$$PATH$$/3840.dat';

--
-- Data for Name: impuesto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.impuesto (id, descripcion, estado) FROM stdin;
\.
COPY public.impuesto (id, descripcion, estado) FROM '$$PATH$$/3842.dat';

--
-- Data for Name: item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item (id, descripcion, precio, stock, id_marca, estado) FROM stdin;
\.
COPY public.item (id, descripcion, precio, stock, id_marca, estado) FROM '$$PATH$$/3844.dat';

--
-- Data for Name: marca; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.marca (id, descripcion, estado) FROM stdin;
\.
COPY public.marca (id, descripcion, estado) FROM '$$PATH$$/3846.dat';

--
-- Data for Name: motivo_ajuste; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.motivo_ajuste (id, descripcion, estado) FROM stdin;
\.
COPY public.motivo_ajuste (id, descripcion, estado) FROM '$$PATH$$/3848.dat';

--
-- Data for Name: orden_trabajo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orden_trabajo (id, fecha_ingreso, fecha_limite, id_presupuesto, estado, id_usuario) FROM stdin;
\.
COPY public.orden_trabajo (id, fecha_ingreso, fecha_limite, id_presupuesto, estado, id_usuario) FROM '$$PATH$$/3850.dat';

--
-- Data for Name: pedido_compra; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pedido_compra (id, estado, fecha, id_deposito, id_estado, id_usuario, observacion) FROM stdin;
\.
COPY public.pedido_compra (id, estado, fecha, id_deposito, id_estado, id_usuario, observacion) FROM '$$PATH$$/3896.dat';

--
-- Data for Name: pedido_compra_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pedido_compra_detalle (id, cantidad, estado, id_articulo, id_pedido_compra) FROM stdin;
\.
COPY public.pedido_compra_detalle (id, cantidad, estado, id_articulo, id_pedido_compra) FROM '$$PATH$$/3894.dat';

--
-- Data for Name: permiso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.permiso (id, id_rol, id_formulario, agregar, modificar, eliminar, consultar, listar, informe, exportar, id_usuario_auditoria, estado, reactivar) FROM stdin;
\.
COPY public.permiso (id, id_rol, id_formulario, agregar, modificar, eliminar, consultar, listar, informe, exportar, id_usuario_auditoria, estado, reactivar) FROM '$$PATH$$/3852.dat';

--
-- Data for Name: persona; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.persona (id, nombre, apellido, ci, telefono, direccion, id_ciudad, estado) FROM stdin;
\.
COPY public.persona (id, nombre, apellido, ci, telefono, direccion, id_ciudad, estado) FROM '$$PATH$$/3824.dat';

--
-- Data for Name: presupuesto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.presupuesto (id, id_usuario, id_diagnostico, fecha, estado, total) FROM stdin;
\.
COPY public.presupuesto (id, id_usuario, id_diagnostico, fecha, estado, total) FROM '$$PATH$$/3854.dat';

--
-- Data for Name: presupuesto_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.presupuesto_detalle (id_presupuesto, id_item, cantidad, precio, id, estado) FROM stdin;
\.
COPY public.presupuesto_detalle (id_presupuesto, id_item, cantidad, precio, id, estado) FROM '$$PATH$$/3855.dat';

--
-- Data for Name: proveedor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.proveedor (id, razon_social, ruc, telefono, correo, direccion, id_ciudad, estado) FROM stdin;
\.
COPY public.proveedor (id, razon_social, ruc, telefono, correo, direccion, id_ciudad, estado) FROM '$$PATH$$/3857.dat';

--
-- Data for Name: recepcion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recepcion (id, id_usuario, id_equipo, defecto, fecha, estado) FROM stdin;
\.
COPY public.recepcion (id, id_usuario, id_equipo, defecto, fecha, estado) FROM '$$PATH$$/3860.dat';

--
-- Data for Name: rol; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rol (id, nombre, id_usuario_auditoria, estado) FROM stdin;
\.
COPY public.rol (id, nombre, id_usuario_auditoria, estado) FROM '$$PATH$$/3862.dat';

--
-- Data for Name: servicio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.servicio (id, tipo, id_orden_trabajo, fecha, estado, id_usuario, observacion) FROM stdin;
\.
COPY public.servicio (id, tipo, id_orden_trabajo, fecha, estado, id_usuario, observacion) FROM '$$PATH$$/3864.dat';

--
-- Data for Name: sistema; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sistema (id, nombre, id_usuario_auditoria, estado) FROM stdin;
\.
COPY public.sistema (id, nombre, id_usuario_auditoria, estado) FROM '$$PATH$$/3866.dat';

--
-- Data for Name: sub_menu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sub_menu (id, nombre, id_usuario_auditoria, estado) FROM stdin;
\.
COPY public.sub_menu (id, nombre, id_usuario_auditoria, estado) FROM '$$PATH$$/3868.dat';

--
-- Data for Name: sucursal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sucursal (id, descripcion, telefono, direccion, estado, id_ciudad) FROM stdin;
\.
COPY public.sucursal (id, descripcion, telefono, direccion, estado, id_ciudad) FROM '$$PATH$$/3870.dat';

--
-- Data for Name: tarjeta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tarjeta (id, descripcion, estado) FROM stdin;
\.
COPY public.tarjeta (id, descripcion, estado) FROM '$$PATH$$/3872.dat';

--
-- Data for Name: timbrado; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.timbrado (id, id_caja, numero, tipo, fecha_inicio, fecha_fin, inicio, fin, actual, estado) FROM stdin;
\.
COPY public.timbrado (id, id_caja, numero, tipo, fecha_inicio, fecha_fin, inicio, fin, actual, estado) FROM '$$PATH$$/3874.dat';

--
-- Data for Name: tipo_articulo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipo_articulo (id, descripcion, estado) FROM stdin;
\.
COPY public.tipo_articulo (id, descripcion, estado) FROM '$$PATH$$/3876.dat';

--
-- Data for Name: tipo_cheque; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipo_cheque (id, descripcion, estado) FROM stdin;
\.
COPY public.tipo_cheque (id, descripcion, estado) FROM '$$PATH$$/3878.dat';

--
-- Data for Name: tipo_documento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipo_documento (id, descripcion, estado) FROM stdin;
\.
COPY public.tipo_documento (id, descripcion, estado) FROM '$$PATH$$/3880.dat';

--
-- Data for Name: tipo_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipo_item (id, descripcion, estado) FROM stdin;
\.
COPY public.tipo_item (id, descripcion, estado) FROM '$$PATH$$/3882.dat';

--
-- Data for Name: tipo_problema; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipo_problema (id, descripcion, estado) FROM stdin;
\.
COPY public.tipo_problema (id, descripcion, estado) FROM '$$PATH$$/3883.dat';

--
-- Data for Name: tipo_tarjeta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipo_tarjeta (id, descripcion, estado) FROM stdin;
\.
COPY public.tipo_tarjeta (id, descripcion, estado) FROM '$$PATH$$/3885.dat';

--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuario (id, nombre, usuario, clave, imagen, id_usuario_auditoria, estado, id_sucursal) FROM stdin;
\.
COPY public.usuario (id, nombre, usuario, clave, imagen, id_usuario_auditoria, estado, id_sucursal) FROM '$$PATH$$/3887.dat';

--
-- Data for Name: usuario_rol; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuario_rol (id, id_usuario, id_rol, id_usuario_auditoria, estado) FROM stdin;
\.
COPY public.usuario_rol (id, id_usuario, id_rol, id_usuario_auditoria, estado) FROM '$$PATH$$/3888.dat';

--
-- Name: accesorios_acces_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accesorios_acces_id_seq', 4, true);


--
-- Name: articulo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.articulo_id_seq', 3, true);


--
-- Name: banco_banco_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.banco_banco_id_seq', 2, true);


--
-- Name: banco_cheque_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.banco_cheque_id_seq', 1, false);


--
-- Name: caja_caja_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.caja_caja_id_seq', 5, true);


--
-- Name: cargo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cargo_id_seq', 1, false);


--
-- Name: ciudad_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ciudad_id_seq', 5, true);


--
-- Name: clientes_cli_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.clientes_cli_id_seq', 5, true);


--
-- Name: condicion_pago_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.condicion_pago_id_seq', 1, false);


--
-- Name: deposito_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.deposito_id_seq', 8, true);


--
-- Name: detalle_pedido_compra_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.detalle_pedido_compra_id_seq', 1, true);


--
-- Name: detalle_pedido_compra_id_seq1; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.detalle_pedido_compra_id_seq1', 1, false);


--
-- Name: diagnostico_diagno_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.diagnostico_diagno_id_seq', 9, true);


--
-- Name: empleado_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.empleado_id_seq', 1, false);


--
-- Name: empresa_empre_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.empresa_empre_id_seq', 6, true);


--
-- Name: encargado_enca_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.encargado_enca_id_seq', 3, true);


--
-- Name: entidad_emisora_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.entidad_emisora_id_seq', 1, false);


--
-- Name: equipoaccesorio_id_equipoaccesorio_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.equipoaccesorio_id_equipoaccesorio_seq', 6, true);


--
-- Name: equipos_equi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.equipos_equi_id_seq', 15, true);


--
-- Name: estado_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.estado_id_seq', 3, true);


--
-- Name: forma_cobro_form_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.forma_cobro_form_id_seq', 4, true);


--
-- Name: formularios_id_formulario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.formularios_id_formulario_seq', 36, true);


--
-- Name: impuesto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.impuesto_id_seq', 3, true);


--
-- Name: items_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.items_item_id_seq', 3, true);


--
-- Name: marcas_mar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.marcas_mar_id_seq', 36, true);


--
-- Name: motivo_ajuste_maju_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.motivo_ajuste_maju_id_seq', 2, true);


--
-- Name: orden_trabajo_orden_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orden_trabajo_orden_id_seq', 5, true);


--
-- Name: pedido_compra_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pedido_compra_id_seq', 1, true);


--
-- Name: permisos_id_permiso_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.permisos_id_permiso_seq', 42, true);


--
-- Name: presupuesto_detalle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.presupuesto_detalle_id_seq', 4, true);


--
-- Name: presupuestos_presu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.presupuestos_presu_id_seq', 3, true);


--
-- Name: proveedor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.proveedor_id_seq', 1, false);


--
-- Name: proveedores_prove_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.proveedores_prove_id_seq', 3, true);


--
-- Name: recepcion_recep_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recepcion_recep_id_seq', 16, true);


--
-- Name: roles_id_rol_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_rol_seq', 44, true);


--
-- Name: servicio_servi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.servicio_servi_id_seq', 3, true);


--
-- Name: sistemas_id_sistema_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sistemas_id_sistema_seq', 3, true);


--
-- Name: submenus_id_submenu_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.submenus_id_submenu_seq', 1, false);


--
-- Name: sucursales_suc_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sucursales_suc_id_seq', 7, true);


--
-- Name: tarjeta_tarjeta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tarjeta_tarjeta_id_seq', 2, true);


--
-- Name: timbrado_tim_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.timbrado_tim_id_seq', 2, true);


--
-- Name: tipo_articulo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_articulo_id_seq', 3, true);


--
-- Name: tipo_cheque_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_cheque_id_seq', 1, false);


--
-- Name: tipo_documento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_documento_id_seq', 1, false);


--
-- Name: tipo_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_item_id_seq', 1, false);


--
-- Name: tipo_problemas_tip_proble_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_problemas_tip_proble_id_seq', 2, true);


--
-- Name: tipo_tarjeta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_tarjeta_id_seq', 1, false);


--
-- Name: usuarios_id_usuario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuarios_id_usuario_seq', 4, true);


--
-- Name: usuariosroles_id_usuariorol_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuariosroles_id_usuariorol_seq', 9, true);


--
-- Name: accesorio accesorios_acces_descri_acces_descri1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accesorio
    ADD CONSTRAINT accesorios_acces_descri_acces_descri1_key UNIQUE (descripcion) INCLUDE (descripcion);


--
-- Name: accesorio accesorios_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accesorio
    ADD CONSTRAINT accesorios_pk PRIMARY KEY (id);


--
-- Name: articulo articulo_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articulo
    ADD CONSTRAINT articulo_pk PRIMARY KEY (id);


--
-- Name: articulo articulo_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articulo
    ADD CONSTRAINT articulo_un UNIQUE (descripcion);


--
-- Name: banco_cheque banco_cheque_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banco_cheque
    ADD CONSTRAINT banco_cheque_pk PRIMARY KEY (id);


--
-- Name: banco_cheque banco_cheque_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banco_cheque
    ADD CONSTRAINT banco_cheque_un UNIQUE (descripcion);


--
-- Name: banco banco_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banco
    ADD CONSTRAINT banco_pkey PRIMARY KEY (id);


--
-- Name: banco banco_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banco
    ADD CONSTRAINT banco_un UNIQUE (descripcion);


--
-- Name: caja caja_caja_nro_caja_nro1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.caja
    ADD CONSTRAINT caja_caja_nro_caja_nro1_key UNIQUE (numero) INCLUDE (numero);


--
-- Name: caja caja_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.caja
    ADD CONSTRAINT caja_pkey PRIMARY KEY (id);


--
-- Name: cargo cargo_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cargo
    ADD CONSTRAINT cargo_pk PRIMARY KEY (id);


--
-- Name: cargo cargo_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cargo
    ADD CONSTRAINT cargo_un UNIQUE (descripcion);


--
-- Name: ciudad ciudad_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ciudad
    ADD CONSTRAINT ciudad_pk PRIMARY KEY (id);


--
-- Name: ciudad ciudad_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ciudad
    ADD CONSTRAINT ciudad_un UNIQUE (descripcion);


--
-- Name: cliente clientes_cli_ci_cli_ci1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT clientes_cli_ci_cli_ci1_key UNIQUE (ci) INCLUDE (ci);


--
-- Name: cliente clientes_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT clientes_pk PRIMARY KEY (id);


--
-- Name: condicion_pago condicion_pago_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.condicion_pago
    ADD CONSTRAINT condicion_pago_pk PRIMARY KEY (id);


--
-- Name: condicion_pago condicion_pago_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.condicion_pago
    ADD CONSTRAINT condicion_pago_un UNIQUE (descripcion);


--
-- Name: deposito deposito_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deposito
    ADD CONSTRAINT deposito_pk PRIMARY KEY (id);


--
-- Name: deposito deposito_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deposito
    ADD CONSTRAINT deposito_un UNIQUE (descripcion);


--
-- Name: diagnostico_detalle detalle_diagnostico_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diagnostico_detalle
    ADD CONSTRAINT detalle_diagnostico_pk PRIMARY KEY (id_tipo_problema, id_diagnostico);


--
-- Name: pedido_compra_detalle detalle_pedido_compra_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_compra_detalle
    ADD CONSTRAINT detalle_pedido_compra_pkey PRIMARY KEY (id);


--
-- Name: detalle_pedido_compra detalle_pedido_compra_pkey1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalle_pedido_compra
    ADD CONSTRAINT detalle_pedido_compra_pkey1 PRIMARY KEY (id);


--
-- Name: diagnostico diagnostico_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diagnostico
    ADD CONSTRAINT diagnostico_pk PRIMARY KEY (id);


--
-- Name: empresa empresa_empre_ruc_empre_ruc1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empresa
    ADD CONSTRAINT empresa_empre_ruc_empre_ruc1_key UNIQUE (ruc) INCLUDE (ruc);


--
-- Name: empresa empresa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empresa
    ADD CONSTRAINT empresa_pkey PRIMARY KEY (id);


--
-- Name: encargado encargado_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.encargado
    ADD CONSTRAINT encargado_pkey PRIMARY KEY (id);


--
-- Name: entidad_emisora entidad_emisora_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entidad_emisora
    ADD CONSTRAINT entidad_emisora_pk PRIMARY KEY (id);


--
-- Name: entidad_emisora entidad_emisora_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entidad_emisora
    ADD CONSTRAINT entidad_emisora_un UNIQUE (descripcion);


--
-- Name: equipo_accesorio equipoaccesorio_acces_id_equi_id_equi_id1_acces_id1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipo_accesorio
    ADD CONSTRAINT equipoaccesorio_acces_id_equi_id_equi_id1_acces_id1_key UNIQUE (id_accesorio, id_equipo) INCLUDE (id_equipo, id_accesorio);


--
-- Name: equipo_accesorio equipoaccesorio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipo_accesorio
    ADD CONSTRAINT equipoaccesorio_pkey PRIMARY KEY (id);


--
-- Name: equipo equipos_equi_serie_equi_serie1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipo
    ADD CONSTRAINT equipos_equi_serie_equi_serie1_key UNIQUE (serie) INCLUDE (serie);


--
-- Name: equipo equipos_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipo
    ADD CONSTRAINT equipos_pk PRIMARY KEY (id);


--
-- Name: estado estado_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado
    ADD CONSTRAINT estado_pk PRIMARY KEY (id);


--
-- Name: estado estado_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado
    ADD CONSTRAINT estado_un UNIQUE (descripcion);


--
-- Name: forma_cobro forma_cobro_form_descri_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forma_cobro
    ADD CONSTRAINT forma_cobro_form_descri_key UNIQUE (descripcion);


--
-- Name: forma_cobro forma_cobro_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forma_cobro
    ADD CONSTRAINT forma_cobro_pkey PRIMARY KEY (id);


--
-- Name: formulario formularios_id_formulario_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.formulario
    ADD CONSTRAINT formularios_id_formulario_pk PRIMARY KEY (id);


--
-- Name: formulario formularios_url_formulario_url_formulario1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.formulario
    ADD CONSTRAINT formularios_url_formulario_url_formulario1_key UNIQUE (url) INCLUDE (url);


--
-- Name: impuesto impuesto_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.impuesto
    ADD CONSTRAINT impuesto_pk PRIMARY KEY (id);


--
-- Name: impuesto impuesto_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.impuesto
    ADD CONSTRAINT impuesto_un UNIQUE (descripcion);


--
-- Name: item item_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item
    ADD CONSTRAINT item_pk PRIMARY KEY (id);


--
-- Name: item items_item_descri_item_descri1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item
    ADD CONSTRAINT items_item_descri_item_descri1_key UNIQUE (descripcion) INCLUDE (descripcion);


--
-- Name: marca marca_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marca
    ADD CONSTRAINT marca_un UNIQUE (descripcion);


--
-- Name: marca marcas_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marca
    ADD CONSTRAINT marcas_pk PRIMARY KEY (id);


--
-- Name: motivo_ajuste motivo_ajuste_maju_descri_maju_descri1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.motivo_ajuste
    ADD CONSTRAINT motivo_ajuste_maju_descri_maju_descri1_key UNIQUE (descripcion) INCLUDE (descripcion);


--
-- Name: motivo_ajuste motivo_ajuste_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.motivo_ajuste
    ADD CONSTRAINT motivo_ajuste_pkey PRIMARY KEY (id);


--
-- Name: orden_trabajo orden_trabajo_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden_trabajo
    ADD CONSTRAINT orden_trabajo_pk PRIMARY KEY (id);


--
-- Name: pedido_compra pedido_compra_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_compra
    ADD CONSTRAINT pedido_compra_pkey PRIMARY KEY (id);


--
-- Name: permiso permisos_id_permiso_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permiso
    ADD CONSTRAINT permisos_id_permiso_pk PRIMARY KEY (id);


--
-- Name: persona persona_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona
    ADD CONSTRAINT persona_pk PRIMARY KEY (id);


--
-- Name: persona persona_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona
    ADD CONSTRAINT persona_un UNIQUE (ci);


--
-- Name: presupuesto_detalle presupuesto_detalle_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_detalle
    ADD CONSTRAINT presupuesto_detalle_pk PRIMARY KEY (id);


--
-- Name: presupuesto presupuestos_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto
    ADD CONSTRAINT presupuestos_pk PRIMARY KEY (id);


--
-- Name: proveedor proveedores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proveedor
    ADD CONSTRAINT proveedores_pkey PRIMARY KEY (id);


--
-- Name: proveedor proveedores_prove_ruc_prove_ruc1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proveedor
    ADD CONSTRAINT proveedores_prove_ruc_prove_ruc1_key UNIQUE (ruc) INCLUDE (ruc);


--
-- Name: recepcion recepcion_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recepcion
    ADD CONSTRAINT recepcion_pk PRIMARY KEY (id);


--
-- Name: rol roles_id_rol_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rol
    ADD CONSTRAINT roles_id_rol_pk PRIMARY KEY (id);


--
-- Name: rol roles_nombre_rol_unk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rol
    ADD CONSTRAINT roles_nombre_rol_unk UNIQUE (nombre);


--
-- Name: servicio servicio_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.servicio
    ADD CONSTRAINT servicio_pk PRIMARY KEY (id);


--
-- Name: sistema sistemas_id_sistema_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sistema
    ADD CONSTRAINT sistemas_id_sistema_pk PRIMARY KEY (id);


--
-- Name: sistema sistemas_nombre_sistema_unk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sistema
    ADD CONSTRAINT sistemas_nombre_sistema_unk UNIQUE (nombre);


--
-- Name: sub_menu submenus_id_submenu_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_menu
    ADD CONSTRAINT submenus_id_submenu_pk PRIMARY KEY (id);


--
-- Name: sub_menu submenus_nombre_submenu_unk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_menu
    ADD CONSTRAINT submenus_nombre_submenu_unk UNIQUE (nombre);


--
-- Name: sucursal sucursales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sucursal
    ADD CONSTRAINT sucursales_pkey PRIMARY KEY (id);


--
-- Name: sucursal sucursales_suc_descri_suc_descri1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sucursal
    ADD CONSTRAINT sucursales_suc_descri_suc_descri1_key UNIQUE (descripcion) INCLUDE (descripcion);


--
-- Name: tarjeta tarjeta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tarjeta
    ADD CONSTRAINT tarjeta_pkey PRIMARY KEY (id);


--
-- Name: tarjeta tarjeta_tarjeta_descri_tarjeta_descri1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tarjeta
    ADD CONSTRAINT tarjeta_tarjeta_descri_tarjeta_descri1_key UNIQUE (descripcion) INCLUDE (descripcion);


--
-- Name: timbrado timbrado_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.timbrado
    ADD CONSTRAINT timbrado_pk PRIMARY KEY (id);


--
-- Name: timbrado timbrado_tim_nro_tim_nro1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.timbrado
    ADD CONSTRAINT timbrado_tim_nro_tim_nro1_key UNIQUE (numero) INCLUDE (numero);


--
-- Name: tipo_articulo tipo_articulo_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_articulo
    ADD CONSTRAINT tipo_articulo_pk PRIMARY KEY (id);


--
-- Name: tipo_articulo tipo_articulo_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_articulo
    ADD CONSTRAINT tipo_articulo_un UNIQUE (descripcion);


--
-- Name: tipo_cheque tipo_cheque_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_cheque
    ADD CONSTRAINT tipo_cheque_pk PRIMARY KEY (id);


--
-- Name: tipo_cheque tipo_cheque_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_cheque
    ADD CONSTRAINT tipo_cheque_un UNIQUE (descripcion);


--
-- Name: tipo_documento tipo_documento_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_documento
    ADD CONSTRAINT tipo_documento_pk PRIMARY KEY (id);


--
-- Name: tipo_documento tipo_documento_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_documento
    ADD CONSTRAINT tipo_documento_un UNIQUE (descripcion);


--
-- Name: tipo_item tipo_item_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_item
    ADD CONSTRAINT tipo_item_pk PRIMARY KEY (id);


--
-- Name: tipo_item tipo_item_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_item
    ADD CONSTRAINT tipo_item_un UNIQUE (descripcion);


--
-- Name: tipo_problema tipo_problemas_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_problema
    ADD CONSTRAINT tipo_problemas_pk PRIMARY KEY (id);


--
-- Name: tipo_problema tipo_problemas_tipo_descri_tipo_descri1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_problema
    ADD CONSTRAINT tipo_problemas_tipo_descri_tipo_descri1_key UNIQUE (descripcion) INCLUDE (descripcion);


--
-- Name: tipo_tarjeta tipo_tarjeta_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_tarjeta
    ADD CONSTRAINT tipo_tarjeta_pk PRIMARY KEY (id);


--
-- Name: tipo_tarjeta tipo_tarjeta_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_tarjeta
    ADD CONSTRAINT tipo_tarjeta_un UNIQUE (descripcion);


--
-- Name: usuario usuarios_id_usuario_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuarios_id_usuario_pk PRIMARY KEY (id);


--
-- Name: usuario usuarios_usuario_usuario_usuario_usuario1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuarios_usuario_usuario_usuario_usuario1_key UNIQUE (usuario) INCLUDE (usuario);


--
-- Name: usuario_rol usuariosroles_id_usuario_id_rol_id_usuario1_id_rol1_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario_rol
    ADD CONSTRAINT usuariosroles_id_usuario_id_rol_id_usuario1_id_rol1_key UNIQUE (id_usuario, id_rol) INCLUDE (id_usuario, id_rol);


--
-- Name: usuario_rol usuariosroles_id_usuariorol_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario_rol
    ADD CONSTRAINT usuariosroles_id_usuariorol_pk PRIMARY KEY (id);


--
-- Name: marcas_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX marcas_index ON public.marca USING btree (lower((descripcion)::text));


--
-- Name: presupuesto_detalle actualizar_total_presupuesto; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER actualizar_total_presupuesto AFTER INSERT ON public.presupuesto_detalle FOR EACH ROW EXECUTE FUNCTION public.calcular_total_presupuesto();


--
-- Name: articulo articulo_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articulo
    ADD CONSTRAINT articulo_fk FOREIGN KEY (id_impuesto) REFERENCES public.impuesto(id);


--
-- Name: articulo articulo_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articulo
    ADD CONSTRAINT articulo_fk_1 FOREIGN KEY (id_marca) REFERENCES public.marca(id);


--
-- Name: articulo articulo_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articulo
    ADD CONSTRAINT articulo_fk_2 FOREIGN KEY (id_tipo_articulo) REFERENCES public.tipo_articulo(id);


--
-- Name: deposito deposito_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deposito
    ADD CONSTRAINT deposito_fk FOREIGN KEY (id_sucursal) REFERENCES public.sucursal(id);


--
-- Name: diagnostico_detalle diagnostico_detalle_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diagnostico_detalle
    ADD CONSTRAINT diagnostico_detalle_fk FOREIGN KEY (id_diagnostico) REFERENCES public.diagnostico(id);


--
-- Name: diagnostico_detalle diagnostico_detalle_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diagnostico_detalle
    ADD CONSTRAINT diagnostico_detalle_fk_1 FOREIGN KEY (id_tipo_problema) REFERENCES public.tipo_problema(id);


--
-- Name: diagnostico diagnostico_id_usuario_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diagnostico
    ADD CONSTRAINT diagnostico_id_usuario_fk FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- Name: diagnostico diagnostico_recep_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diagnostico
    ADD CONSTRAINT diagnostico_recep_id_fk FOREIGN KEY (id_recepcion) REFERENCES public.recepcion(id);


--
-- Name: persona empleado_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona
    ADD CONSTRAINT empleado_fk FOREIGN KEY (id_ciudad) REFERENCES public.ciudad(id);


--
-- Name: equipo equipo_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipo
    ADD CONSTRAINT equipo_fk FOREIGN KEY (id_marca) REFERENCES public.marca(id);


--
-- Name: equipo_accesorio equipoaccesorio_acces_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipo_accesorio
    ADD CONSTRAINT equipoaccesorio_acces_id_fkey FOREIGN KEY (id_accesorio) REFERENCES public.accesorio(id);


--
-- Name: equipo_accesorio equipoaccesorio_equi_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipo_accesorio
    ADD CONSTRAINT equipoaccesorio_equi_id_fkey FOREIGN KEY (id_equipo) REFERENCES public.equipo(id);


--
-- Name: pedido_compra_detalle fk_detalle_pedido_compra_id_articulo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_compra_detalle
    ADD CONSTRAINT fk_detalle_pedido_compra_id_articulo FOREIGN KEY (id_articulo) REFERENCES public.articulo(id);


--
-- Name: detalle_pedido_compra fk_detalle_pedido_compra_id_articulo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalle_pedido_compra
    ADD CONSTRAINT fk_detalle_pedido_compra_id_articulo FOREIGN KEY (id_articulo) REFERENCES public.articulo(id);


--
-- Name: pedido_compra_detalle fk_detalle_pedido_compra_id_detalle; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_compra_detalle
    ADD CONSTRAINT fk_detalle_pedido_compra_id_detalle FOREIGN KEY (id_pedido_compra) REFERENCES public.pedido_compra(id);


--
-- Name: pedido_compra fk_pedido_compra_id_deposito; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_compra
    ADD CONSTRAINT fk_pedido_compra_id_deposito FOREIGN KEY (id_deposito) REFERENCES public.deposito(id);


--
-- Name: pedido_compra fk_pedido_compra_id_estado; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_compra
    ADD CONSTRAINT fk_pedido_compra_id_estado FOREIGN KEY (id_estado) REFERENCES public.estado(id);


--
-- Name: pedido_compra fk_pedido_compra_id_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_compra
    ADD CONSTRAINT fk_pedido_compra_id_usuario FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- Name: formulario formulario_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.formulario
    ADD CONSTRAINT formulario_fk FOREIGN KEY (id_sistema) REFERENCES public.sistema(id);


--
-- Name: formulario formulario_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.formulario
    ADD CONSTRAINT formulario_fk_1 FOREIGN KEY (id_sub_menu) REFERENCES public.sub_menu(id);


--
-- Name: orden_trabajo orden_trabajo_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden_trabajo
    ADD CONSTRAINT orden_trabajo_fk FOREIGN KEY (id_presupuesto) REFERENCES public.presupuesto(id);


--
-- Name: permiso permiso_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permiso
    ADD CONSTRAINT permiso_fk FOREIGN KEY (id_formulario) REFERENCES public.formulario(id);


--
-- Name: permiso permiso_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permiso
    ADD CONSTRAINT permiso_fk_1 FOREIGN KEY (id_rol) REFERENCES public.rol(id);


--
-- Name: presupuesto_detalle presupuesto_detalle_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_detalle
    ADD CONSTRAINT presupuesto_detalle_fk FOREIGN KEY (id_presupuesto) REFERENCES public.presupuesto(id);


--
-- Name: presupuesto_detalle presupuesto_detalle_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_detalle
    ADD CONSTRAINT presupuesto_detalle_fk1 FOREIGN KEY (id_item) REFERENCES public.item(id);


--
-- Name: presupuesto presupuesto_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto
    ADD CONSTRAINT presupuesto_fk FOREIGN KEY (id_diagnostico) REFERENCES public.diagnostico(id);


--
-- Name: proveedor proveedor_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proveedor
    ADD CONSTRAINT proveedor_fk FOREIGN KEY (id_ciudad) REFERENCES public.ciudad(id);


--
-- Name: recepcion recepcion_equi_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recepcion
    ADD CONSTRAINT recepcion_equi_id_fkey FOREIGN KEY (id_equipo) REFERENCES public.equipo(id);


--
-- Name: recepcion recepcion_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recepcion
    ADD CONSTRAINT recepcion_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- Name: servicio servicio_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.servicio
    ADD CONSTRAINT servicio_fk FOREIGN KEY (id_orden_trabajo) REFERENCES public.orden_trabajo(id);


--
-- Name: sucursal sucursal_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sucursal
    ADD CONSTRAINT sucursal_fk FOREIGN KEY (id_ciudad) REFERENCES public.ciudad(id);


--
-- Name: encargado sucursales_encargado_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.encargado
    ADD CONSTRAINT sucursales_encargado_fk FOREIGN KEY (id_sucursal) REFERENCES public.sucursal(id);


--
-- Name: usuario usuario_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_fk FOREIGN KEY (id_sucursal) REFERENCES public.sucursal(id);


--
-- Name: usuario_rol usuariosroles_id_rol_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario_rol
    ADD CONSTRAINT usuariosroles_id_rol_fk FOREIGN KEY (id_rol) REFERENCES public.rol(id);


--
-- Name: usuario_rol usuariosroles_id_usuario_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario_rol
    ADD CONSTRAINT usuariosroles_id_usuario_fk FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- PostgreSQL database dump complete
--

